#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pooling 阶段: 把多个检索系统的结果汇总成"待标注池"

TREC 官方用 pooling 构建 qrels —— 只把各参赛系统 Top-k 汇总后的文档送人工判定。
这样做的原因: 全库逐条判定不现实; 而未判定的文档在评测时默认不相关。

本脚本:
  1. 读取 N 个系统的 run 文件, 各取 Top-k 汇总去重
  2. 可注入"种子正例"(专家指定的已知正确项), 防止某主题池子全为负例
  3. 随机采样一部分未命中文档作为负例对照(可选, 用于检验系统是否漏召)
  4. 输出待标注 CSV: 每行 = 一个 (主题, 候选文档) 判定单元, 打乱顺序避免标注员看到来源

用法:
  python3 build_pool.py --runs bm25.txt vec.txt hybrid.txt --topk 20 \
      --corpus corpus.jsonl --topics topics.json --seeds seeds.json \
      --out pool_to_annotate.csv
"""
import argparse
import csv
import json
import random
import sys


def read_run(path, topk):
    """run: qid Q0 docid rank score tag -> {qid: [(docid, score), ...]}"""
    by_q = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            p = line.split()
            if len(p) != 6:
                continue
            by_q.setdefault(p[0], []).append((p[2], float(p[4]), int(p[3])))
    out = {}
    for q, items in by_q.items():
        items.sort(key=lambda x: (-x[1], x[2]))
        out[q] = items[:topk]
    return out


def load_jsonl(path):
    d = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            o = json.loads(line)
            d[str(o["docid"])] = o
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", nargs="+", required=True, help="各系统 run 文件, 顺序即 run1..runN")
    ap.add_argument("--topk", type=int, default=20, help="每个系统每主题取前 k 条进入池子")
    ap.add_argument("--corpus", required=True, help="语料 jsonl, 含 docid 与展示字段")
    ap.add_argument("--topics", required=True, help="主题 json: [{id, title, narrative}, ...]")
    ap.add_argument("--seeds", default=None,
                    help="种子正例 json: {topic_id: [docid, ...]}, 强制入池")
    ap.add_argument("--neg-sample", type=int, default=0,
                    help="额外随机采样 N 条未被任何系统召回的文档作负例对照(会显著增大标注量, 谨慎)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    rnd = random.Random(args.seed)
    topics = {str(t["id"]): t for t in json.load(open(args.topics, encoding="utf-8"))}
    corpus = load_jsonl(args.corpus)
    seeds = json.load(open(args.seeds, encoding="utf-8")) if args.seeds else {}

    runs = [read_run(r, args.topk) for r in args.runs]
    all_topics = sorted(set().union(*[set(r) for r in runs]) | set(topics))

    rows, stats = [], []
    for qid in all_topics:
        pool = {}          # docid -> 命中来源集合
        for i, r in enumerate(runs, 1):
            for docid, score, rank in r.get(qid, []):
                pool.setdefault(docid, set()).add(i)
        n_from_runs = len(pool)
        for d in seeds.get(qid, []):
            pool.setdefault(d, set()).add(0)   # 0 = 种子正例

        if args.neg_sample and len(corpus) > len(pool):
            cand = [d for d in corpus if d not in pool]
            for d in rnd.sample(cand, min(args.neg_sample, len(cand))):
                pool.setdefault(d, set()).add(-1)  # -1 = 随机负例对照

        for docid, srcs in pool.items():
            c = corpus.get(docid, {})
            rows.append({
                "topic_id": qid,
                "topic_title": topics.get(qid, {}).get("title", ""),
                "topic_narrative": topics.get(qid, {}).get("narrative", ""),
                "docid": docid,
                "doc_text": str(c.get("text", c.get("content", "")))[:1200],
                "doc_meta": json.dumps({k: v for k, v in c.items()
                                        if k not in ("text", "content", "docid")},
                                       ensure_ascii=False),
                "sources": "|".join(str(s) for s in sorted(srcs)),
            })
        stats.append((qid, n_from_runs, len(pool)))

    rnd.shuffle(rows)   # 打乱, 避免标注员猜到来源与主题分组

    with open(args.out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()) + ["grade_A", "grade_B", "note"])
        w.writeheader()
        for r in rows:
            r["grade_A"] = r["grade_B"] = r["note"] = ""
            w.writerow(r)

    tot = sum(s[2] for s in stats)
    print("=" * 66)
    print("Pooling 完成: %d 个主题, %d 个待标注判定单元" % (len(stats), tot))
    print("平均每主题 %.1f 条 (最小 %d, 最大 %d)" %
          (tot / max(1, len(stats)), min(s[2] for s in stats), max(s[2] for s in stats)))
    print("预估标注工时: 按 30 秒/条计约 %.1f 小时/人" % (tot * 30 / 3600))
    print("输出: %s" % args.out)
    print("=" * 66)
    print("\n主题 | 系统召回条数 | 入池条数")
    for qid, a, b in stats[:20]:
        print("  %-6s %6d %8d" % (qid, a, b))
    if len(stats) > 20:
        print("  ... 共 %d 个主题" % len(stats))
    empty = [q for q, a, b in stats if b == 0]
    if empty:
        print("\n[警告] 以下主题池子为空, 需要补充种子正例或检查系统: %s" % empty[:10])
    return 0


if __name__ == "__main__":
    sys.exit(main())
