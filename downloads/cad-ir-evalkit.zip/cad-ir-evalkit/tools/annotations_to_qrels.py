#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
标注阶段 -> 生成 TREC qrels + 标注一致性报告

输入: build_pool.py 产出的 CSV, 标注员 A / B 分别填了 grade_A / grade_B 两列
输出:
  qrels.txt         TREC 标准格式 (topic_id 0 docid grade)
  disagreements.csv 两人分歧清单, 交第三人仲裁
  report.txt        一致性报告 (Cohen's kappa / quadratic weighted kappa)

分级规范 (4 级, 与 TREC DL 一致, 便于直接复用 -l 2 口径):
  0 = 不相关
  1 = 弱相关: 同工程类别, 但未命中关键参数
  2 = 相关  : 命中主要参数, 可作为参考
  3 = 完全匹配: 关键参数全部命中, 可直接采用

用法:
  python3 annotations_to_qrels.py --annotated pool_annotated.csv --out qrels.txt
  python3 annotations_to_qrels.py --annotated pool.csv --strategy min --kappa-threshold 0.6
"""
import argparse
import collections
import csv
import statistics
import sys

OK, WARN, ERR = "  [OK]  ", "  [WARN]", "  [ERR] "


def cohen_kappa(pairs):
    """未加权 Cohen's kappa"""
    n = len(pairs)
    if n == 0:
        return float("nan")
    po = sum(1 for a, b in pairs if a == b) / n
    ca, cb = collections.Counter(a for a, _ in pairs), collections.Counter(b for _, b in pairs)
    pe = sum((ca[k] / n) * (cb[k] / n) for k in set(ca) | set(cb))
    return (po - pe) / (1 - pe) if pe < 1 else 1.0


def weighted_kappa(pairs, power=2):
    """加权 kappa, power=1 线性, power=2 二次(有序等级推荐)"""
    n = len(pairs)
    if n == 0:
        return float("nan")
    grades = [g for pair in pairs for g in pair]
    lo, hi = min(grades), max(grades)
    rng = hi - lo
    if rng == 0:
        return 1.0
    w = {(i, j): (abs(i - j) / rng) ** power for i in range(lo, hi + 1) for j in range(lo, hi + 1)}
    num = sum(w[(a, b)] for a, b in pairs) / n
    ca, cb = collections.Counter(a for a, _ in pairs), collections.Counter(b for _, b in pairs)
    den = sum((ca[i] / n) * (cb[j] / n) * w[(i, j)]
              for i in range(lo, hi + 1) for j in range(lo, hi + 1))
    return 1 - num / den if den else 1.0


def resolve(a, b, strategy):
    if strategy == "mean_round":
        return int(round((a + b) / 2))
    if strategy == "min":          # 保守: 取低分
        return min(a, b)
    if strategy == "max":
        return max(a, b)
    if strategy == "a":            # 以 A 为准 (A 为资深标注员时)
        return a
    raise ValueError(strategy)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--annotated", required=True)
    ap.add_argument("--out", default="qrels.txt")
    ap.add_argument("--strategy", default="mean_round",
                    choices=["mean_round", "min", "max", "a"],
                    help="两人不一致时的合并策略; 分歧大的建议导出后由第三人仲裁再重跑")
    ap.add_argument("--kappa-threshold", type=float, default=0.6,
                    help="二次加权 kappa 低于此值判定为标注规范需修订")
    ap.add_argument("-l", "--min-grade-for-rel", type=int, default=2,
                    help="报告里统计'相关'所用的阈值, 需与评测时 trec_eval -l 一致")
    args = ap.parse_args()

    rows = list(csv.DictReader(open(args.annotated, encoding="utf-8-sig")))
    pairs, parsed, missing = [], [], 0
    for r in rows:
        ga, gb = (r.get("grade_A") or "").strip(), (r.get("grade_B") or "").strip()
        if ga == "" or gb == "":
            missing += 1
            continue
        try:
            a, b = int(float(ga)), int(float(gb))
        except ValueError:
            missing += 1
            continue
        pairs.append((a, b))
        parsed.append((r, a, b))

    print("=" * 70)
    print("标注一致性报告  |  %s" % args.annotated)
    print("=" * 70)
    print("总判定单元=%d  有效=%d  缺失/非法=%d" % (len(rows), len(parsed), missing))

    if not parsed:
        print(ERR + "没有任何有效标注。")
        return 1

    k = cohen_kappa(pairs)
    wk = weighted_kappa(pairs, power=2)
    agree = sum(1 for a, b in pairs if a == b) / len(pairs)
    adjacent = sum(1 for a, b in pairs if abs(a - b) <= 1) / len(pairs)
    sev = sum(1 for a, b in pairs if abs(a - b) >= 2) / len(pairs)

    print("\n[一致性]")
    print("  完全一致率            : %.3f" % agree)
    print("  相邻一致率(|差|<=1)   : %.3f" % adjacent)
    print("  严重分歧率(|差|>=2)   : %.3f" % sev)
    print("  Cohen's kappa         : %.3f" % k)
    print("  二次加权 kappa (推荐) : %.3f" % wk)

    print("\n[判定]")
    if wk >= args.kappa_threshold:
        print(OK + "一致性达标 (>= %.2f), 可据此生成 qrels。" % args.kappa_threshold)
    else:
        print(WARN + "一致性不足 (< %.2f)。" % args.kappa_threshold)
        print("       处理顺序: 1) 修订标注规范(尤其 narrative 与分级边界) "
              "2) 对标注员重新校准 3) 分歧项交第三人仲裁。")

    # 分歧清单
    dis = [r for r, a, b in parsed if a != b]
    if dis:
        with open("disagreements.csv", "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()) + ["adjudicated"])
            w.writeheader()
            for r in dis:
                r = dict(r)
                r["adjudicated"] = ""
                w.writerow(r)
        print("\n[分歧] %d 条 (%.1f%%), 已导出 disagreements.csv 供仲裁。"
              % (len(dis), 100.0 * len(dis) / len(parsed)))

    # 生成 qrels
    with open(args.out, "w", encoding="utf-8") as f:
        for r, a, b in parsed:
            f.write("%s 0 %s %d\n" % (r["topic_id"], r["docid"], resolve(a, b, args.strategy)))

    # qrels 体检
    by_topic = collections.defaultdict(list)
    for r, a, b in parsed:
        by_topic[r["topic_id"]].append(resolve(a, b, args.strategy))
    nt = len(by_topic)
    npos = sum(1 for v in by_topic.values() if any(g >= args.min_grade_for_rel for g in v))
    print("\n[qrels 体检] 输出: %s" % args.out)
    print("  主题数=%d   判定条数=%d" % (nt, len(parsed)))
    print("  等级分布=%s" % dict(sorted(collections.Counter(
        resolve(a, b, args.strategy) for _, a, b in parsed).items())))
    print("  每主题判定数: 平均 %.1f, 最小 %d, 最大 %d" %
          (statistics.mean(len(v) for v in by_topic.values()),
           min(len(v) for v in by_topic.values()), max(len(v) for v in by_topic.values())))
    if npos < nt:
        print(WARN + "有 %d/%d 个主题在 rel>=%d 上无正例, 这些主题所有系统都得 0, "
                     "会稀释整体均值 —— 建议补充种子正例或复核标注。"
              % (nt - npos, nt, args.min_grade_for_rel))
    else:
        print(OK + "全部主题均有 rel>=%d 的正例。" % args.min_grade_for_rel)
    if nt < 30:
        print(WARN + "主题数 %d < 30, 统计功效不足, 组间差异很难显著。建议扩到 40-60 个主题。" % nt)
    else:
        print(OK + "主题数 %d, 具备基本统计功效。" % nt)

    print("\n[下一步]")
    print("  python3 ../trec-eval-kit/tools/eval_official.py "
          "--qrels %s --run <你的run> -l %d" % (args.out, args.min_grade_for_rel))
    return 0


if __name__ == "__main__":
    sys.exit(main())
