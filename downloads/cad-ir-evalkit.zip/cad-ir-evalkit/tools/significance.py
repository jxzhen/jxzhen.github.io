#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
两个系统的差异是否显著: paired bootstrap + paired t 检验

自建评测集主题数通常只有 30-60 个, 直接比较均值点估计极易误判。
论文/汇报里必须给出置信区间与 p 值。

方法:
  paired bootstrap  对主题重采样 B 次, 统计 (A-B) 差异的分布
  paired t-test     作为交叉验证 (样本 >= 30 时较可靠)

判读:
  差异的 95% CI 不含 0 且 p < 0.05  -> 显著差异
  CI 跨 0                          -> 不能宣称更优, 只能说数值上更高

用法:
  python3 significance.py --qrels qrels.txt --run-a bm25.txt --run-b hybrid.txt -l 2
  python3 significance.py --qrels qrels.txt --run-a a.txt --run-b b.txt --metric ndcg_cut_10 -B 10000
"""
import argparse
import random
import statistics
import sys

import pytrec_eval


def load_qrels(path):
    out = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            p = line.split()
            if len(p) == 4:
                out.setdefault(p[0], {})[p[2]] = int(p[3])
    return out


def load_run(path, max_docs=1000):
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            p = line.split()
            if len(p) == 6:
                rows.append((p[0], p[2], float(p[4]), int(p[3])))
    by_q = {}
    for q, d, s, r in rows:
        by_q.setdefault(q, []).append((s, r, d))
    return {q: {d: s for s, _, d in sorted(v, key=lambda x: (-x[0], x[1]))[:max_docs]}
            for q, v in by_q.items()}


def per_topic_scores(qrels, run, metric, rel_level, max_docs):
    ev = pytrec_eval.RelevanceEvaluator(qrels, {metric.split("_")[0] if "_" not in metric
                                                else metric.rsplit("_", 1)[0]},
                                        relevance_level=rel_level)
    res = ev.evaluate(run)
    return {t: res.get(t, {}).get(metric, 0.0) for t in qrels}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--qrels", required=True)
    ap.add_argument("--run-a", required=True)
    ap.add_argument("--run-b", required=True)
    ap.add_argument("-l", "--rel-level", type=int, default=2)
    ap.add_argument("-M", "--max-docs", type=int, default=1000)
    ap.add_argument("--metric", default="ndcg_cut_10",
                    help="pytrec_eval 键名, 如 ndcg_cut_10 / map / recip_rank / recall_100 / P_10")
    ap.add_argument("-B", type=int, default=10000, help="bootstrap 重采样次数")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    rnd = random.Random(args.seed)
    qrels = load_qrels(args.qrels)
    sa = per_topic_scores(qrels, load_run(args.run_a, args.max_docs),
                          args.metric, args.rel_level, args.max_docs)
    sb = per_topic_scores(qrels, load_run(args.run_b, args.max_docs),
                          args.metric, args.rel_level, args.max_docs)

    topics = sorted(qrels)
    a = [sa.get(t, 0.0) for t in topics]
    b = [sb.get(t, 0.0) for t in topics]
    diff = [x - y for x, y in zip(a, b)]

    print("=" * 70)
    print("显著性检验 | 指标=%s | 主题数=%d | -l %d | B=%d" %
          (args.metric, len(topics), args.rel_level, args.B))
    print("=" * 70)
    print("A = %s : %.4f" % (args.run_a, statistics.mean(a)))
    print("B = %s : %.4f" % (args.run_b, statistics.mean(b)))
    print("差值 A-B: %+.4f" % statistics.mean(diff))

    # paired bootstrap
    n = len(topics)
    boots = []
    for _ in range(args.B):
        s = [diff[rnd.randrange(n)] for _ in range(n)]
        boots.append(statistics.mean(s))
    boots.sort()
    lo, hi = boots[int(0.025 * args.B)], boots[int(0.975 * args.B)]
    mean_d = statistics.mean(diff)
    # 双尾 p 值: 差值分布跨 0 的比例
    p_boot = 2 * min(sum(1 for x in boots if x <= 0), sum(1 for x in boots if x >= 0)) / args.B
    p_boot = min(1.0, p_boot)

    print("\n[Paired bootstrap, B=%d]" % args.B)
    print("  差值 95%% CI: [%+.4f, %+.4f]" % (lo, hi))
    print("  p 值(双尾) : %.4f" % p_boot)

    # paired t-test
    if n > 1:
        sd = statistics.stdev(diff)
        if sd > 0:
            t = mean_d / (sd / (n ** 0.5))
            print("\n[Paired t-test]  t = %.4f, df = %d" % (t, n - 1))
            print("  (查 t 分布表得 p 值; |t| > 2.04 大致对应 p < 0.05 @ df>=30)")
        else:
            print("\n[Paired t-test] 所有主题差值相同, 无法计算 t 统计量")

    print("\n[结论]")
    if lo > 0:
        print("  差异显著: A 优于 B (CI 下限 > 0, p=%.4f)" % p_boot)
    elif hi < 0:
        print("  差异显著: B 优于 A (CI 上限 < 0, p=%.4f)" % p_boot)
    else:
        print("  差异不显著: 95%% CI 跨越 0。只能报告'数值上 A 比 B 高 %.4f', "
              "不可宣称显著更优。" % mean_d)
    win = sum(1 for x, y in zip(a, b) if x > y)
    lose = sum(1 for x, y in zip(a, b) if x < y)
    print("  逐主题胜负: A 胜 %d / 平 %d / 负 %d" % (win, n - win - lose, lose))
    return 0


if __name__ == "__main__":
    sys.exit(main())
