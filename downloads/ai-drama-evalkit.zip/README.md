# ai-drama-evalkit

单机多剧 AI 剧目生成：产能规划、调度模拟、评审一致性、交付体检。

针对的问题：**一台设备能不能同时产出多部 AI 剧目？能同时几部？并行到底有没有真的提效？**

---

## 工具清单

| 脚本 | 回答的问题 | 零依赖 |
|---|---|---|
| `tools/throughput_sim.py` | 给定 N 部剧，五种调度策略哪个最快 | ✓ |
| `tools/plan_production.py` | 我的设备最多同时跑几部？N 天能交几部？ | ✓ |
| `tools/rubric_score.py` | 这场比赛评得准不准？我的作品排第几？ | ✓ |
| `tools/check_deliverable.py` | 作品会不会被形式问题直接筛掉？ | ✓ |

四个脚本只用 Python 标准库，实测 `python3.12` 通过。`ffprobe` 是可选增强。

---

## 1. throughput_sim.py —— 调度策略模拟

离散事件模拟，对比 5 种排产方式：

| 策略 | 做法 |
|---|---|
| `serial` | 一部剧做完再做下一部 |
| `fifo` | 严格按镜头提交顺序，不归类 |
| `round_robin` | 各剧轮流各出一镜头 |
| `batch_by_drama` | 同剧镜头连续排产 |
| `pipeline` | 按剧批量 + CPU 阶段与 GPU 重叠 |

```bash
python3.12 tools/throughput_sim.py
```

实测（默认 2 卡 × 24GB、3 部剧）：

```
             策略        总完工h↓      GPU利用率↑        切换次数↓        切换开销↓       首集交付h↓       镜头/小时↑
         serial         9.01        86.7%            2         0.1%         3.32         66.6
           fifo        12.32        63.4%          599        27.0%         1.25         48.7
      round_robin      12.32        63.4%          599        27.0%         1.25         48.7
   batch_by_drama       9.41        83.0%           74         4.4%         0.97         63.8
        pipeline        8.24        94.8%           74         5.0%         0.86         72.8

 吞吐最优：pipeline（72.8 镜头/小时，相对串行 +9.3%）
 首集最快：pipeline（0.86 h，相对串行 -74.1%）
```

**结论**：并发把首集交付时间砍掉 74%，但总吞吐只涨 9%。想提吞吐，只能降 `t_video`。

---

## 2. plan_production.py —— 产能反解

反着来：给定设备与工期，算上限。三道墙：

- **显存墙（硬）**：`floor((显存 - 共享 - 预留) / 单剧工作集)`，决定**同时**并行数
- **时间墙（软）**：总 GPU 工时 / 并发 / 利用率，决定**累计**交付数
- **切换墙（效率）**：换剧开销占比，决定实际利用率

```bash
python3.12 tools/plan_production.py --dump-config my.json   # 导出参数模板
# 改 my.json 填入你的实测值
python3.12 tools/plan_production.py --config my.json --deadline-days 3
python3.12 tools/plan_production.py --gpus 4 --vram 24 --dramas 6
```

实测（2 卡 × 24GB，3 天工期）：

```
单卡可常驻剧目数：1 部 → 整机槽位数：2 个
并行 1→2 部：单镜头摊薄 3.26 → 1.65 分钟（+97.7%）
并行 2→3 部：-0.1%  ← 饱和，饱和点正好等于槽位数
3 天内累计可交付 36 部（分 18 批），但同时并行上限仍为 2 部
```

**关键区分**：`同时并行数`（显存钉死）与`累计交付数`（时间可堆）是两个不同的数，只报一个必然误导。

---

## 3. rubric_score.py —— 评审一致性与排名

默认量表取自**虎鲸文娱「鲸锐 AI 创作大赛」**四维评审口径：选题创意 / 叙事技巧 / 视听语言 / 社会价值。

产出三个客观指标：

- **Kendall's W**（含并列校正）：评委排序一致性
- **留一法翻转率**：去掉任一评委，前三名变不变
- **硬门槛**：≥10 分钟成片 / ≥1000 字陈述 / 原创非既有 IP

```bash
python3.12 tools/rubric_score.py --demo
python3.12 tools/rubric_score.py --scores s.csv --rubric jingrui
python3.12 tools/rubric_score.py --scores s.csv --trim 0.1 --export out.json
```

CSV 格式（表头必须含 `work,judge` + 维度列）：

```csv
work,judge,creativity,narrative,audiovisual,social
W1,J1,8.4,7.9,8.1,7.6
W1,J2,8.0,8.2,7.8,7.4
```

实测（5 评委 × 8 作品演示数据）：

```
四维平均 W = 0.528（中等一致，建议开校准会）
留一法：2/5 次导致前三名变化 → 头部可信，边缘名次不可信
```

---

## 4. check_deliverable.py —— 提交前体检

对标 TREC 的 `check_format.py`，在投稿前拦截会被直接筛掉的硬伤。

- **[A] 资格闸门**：时长、故事陈述字数、原创性
- **[B] 技术规格**：分辨率、帧率、音轨存在性与码率（需 ffprobe）
- **[C] 字幕合规**：CPS / CPL / LPB，沿用 IWSLT 2026 中文口径（CPS≤9、CPL≤16、LPB≤2）

```bash
python3.12 tools/check_deliverable.py --demo --original
python3.12 tools/check_deliverable.py --video a.mp4 --srt a.srt \
        --statement story.txt --rule jingrui --original
python3.12 tools/check_deliverable.py --video a.mp4 --rule hema   # 竖屏赛事
```

无 ffprobe 时用 `--declare-*` 声明值，工具会明确标注「未实测」，不伪装成实测。

退出码：有阻塞项返回 1，可直接接进 CI。

---

## 内置赛事规则

| `rule` | 赛事 | 时长 | 分辨率 | 帧率 |
|---|---|---|---|---|
| `jingrui` | 鲸锐 AI 创作大赛 | ≥10 min | 1280×720 | ≥24 |
| `hema` | 河马杯微短剧 | ≥1 min | 1080×1920（竖屏） | ≥25 |
| `generic` | 通用短剧 | ≥5 min | 1280×720 | ≥24 |

---

## 参数说明

所有数字都是**示例值**，必须用你自己的实测数据替换：

| 参数 | 默认 | 含义 |
|---|---|---|
| `t_video_s` | 110 | 单镜头视频生成 GPU 秒数（大头） |
| `t_ref_img_s` | 25 | 参考图/角色定妆 GPU 秒数 |
| `t_tts_s` / `t_mux_s` | 12 / 8 | CPU 侧耗时 |
| `retry_rate` | 0.18 | 废片率，**不计入会严重低估工期** |
| `switch_cost_s` | 45 | 换剧开销（换 LoRA + 重建缓存） |
| `vram_*_gb` | 见源码 | 单剧显存工作集构成 |
| `gpu_util` | 0.82 | 单卡实际利用率 |
| `cpu_overlap` | 0.85 | CPU 阶段与 GPU 重叠比例 |

---

## 单卡单实例架构（推荐）

RTX 4090 24GB **无 NVLink**，4 张卡不是 96GB 统一显存。不要把多卡塞进一个 ComfyUI 实例。

```
                 Python 调度器
                      │ HTTP
      ┌───────────────┼───────────────┐
  ComfyUI :8188  ComfyUI :8189  ComfyUI :8190
    GPU0 24GB      GPU1 24GB      GPU2 24GB
    剧A/B 轮换     剧C/D 轮换     剧E/F 轮换
      └──────── CPU：TTS / 合流 / 封装 ────────┘
```

常用优化参数：`--highvram/--medvram/--lowvram`、`--fp16-unet`、`--bf16-vae`、
`--xformers`、`--cache-lru`、`torch.cuda.empty_cache()`。

---

## 已知限制

1. **参数依赖性强**：输入参数错了结论必然错，工具不会报错。这是最大的使用风险。
2. **未实现一致性自动指标**：角色/风格/闪烁三项只给了口径，未写代码。
3. **只覆盖单机多卡**，多机扩展未涉及。
4. **赛事规则可能变更**，投稿前以官方最新公告为准。
