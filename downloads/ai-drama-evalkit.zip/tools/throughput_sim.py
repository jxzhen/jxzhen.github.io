#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
单设备多剧目并行的吞吐调度模拟器。

要回答的问题
------------
"一台设备能不能同时产出多部剧？"——这个问题必须拆成两个，否则一定答错：

  Q1 总吞吐（一天能出多少镜头/多少集）会不会因为并行而变大？
  Q2 单部剧的交付时间（尤其是首集）会不会因为并行而变短？

Q1 和 Q2 的答案**相反**。GPU 是瓶颈时，总算力恒定，并行不会凭空增加总产出，
反而可能因频繁切换模型（LoRA / 角色卡 / 风格模型）而降低总吞吐；
但并行能显著缩短单剧首集交付时间，并用 CPU 阶段（TTS、合成、IO）去填补
GPU 空闲，从而抬高 GPU 利用率。

本模拟器就是把这个权衡**量化**，而不是靠口号下结论。

模拟模型
--------
每个镜头（shot）是一次任务，含四个阶段：
  ref_img  (GPU) 参考图/角色图生成
  video    (GPU) 视频生成   ← 主要瓶颈
  tts      (CPU) 配音合成
  mux      (CPU) 封装/编码
GPU 阶段串行占用显卡；CPU 阶段可与 GPU 重叠（受 cpu_workers 限制）。
切换到不同剧目时，若该剧的专属模型不在显存中，需付出 switch_cost 的重载代价。

五种调度策略
------------
  serial        逐剧串行：一部做完再做下一部（切换最少）
  fifo          全局 FIFO：所有镜头按生成顺序排队
  round_robin   按剧轮转：每剧轮流交一个镜头（切换最多）
  batch_by_drama 按剧分批：同一部剧连续提交 batch_size 个镜头后换剧
  pipeline      batch_by_drama + CPU/GPU 阶段解耦重叠（推荐）

诚实声明
--------
所有时长参数为**示例值**，默认取自公开经验区间，并非在你机器上的实测。
必须用 --config 传入你的实测值才能得出可用于决策的结论；
在未标定前，本工具用于比较**策略之间的相对关系**，不用于预测绝对产能。

用法
----
  python3 throughput_sim.py
  python3 throughput_sim.py --dramas 4 --episodes 10 --shots 20
  python3 throughput_sim.py --config my_bench.json --json out.json
"""

import argparse
import heapq
import json
import os
import statistics

# --------------------------------------------------- 默认参数（待实测标定）
DEFAULT = {
    # 单镜头各阶段耗时（秒）
    "t_ref_img": 3.0,      # GPU：参考图/角色图
    "t_video": 40.0,       # GPU：视频生成（主瓶颈）
    "t_tts": 2.0,          # CPU：配音合成
    "t_mux": 5.0,          # CPU：封装编码
    # 资源
    "n_gpu": 1,            # GPU 数量
    "cpu_workers": 4,      # 并行 CPU 工作线程
    # 开销
    "model_load": 60.0,    # 冷启动：首次加载模型
    "switch_cost": 20.0,   # 切换剧目导致的模型（LoRA/角色卡）重载代价
    # 规模
    "n_dramas": 3,         # 同时生产的剧目数
    "n_episodes": 10,      # 每部剧集数
    "n_shots": 20,         # 每集镜头数
    # 失败重试（ realism：视频生成有概率需重做）
    "retry_rate": 0.08,
    "batch_size": 8,       # batch_by_drama / pipeline 的批大小
}

PRESET_DESC = {
    "t_video": "720p 5s 视频生成；RTX4090 上 WAN 类模型经验区间约 15~60s",
    "switch_cost": "切换剧目需重载角色 LoRA / 风格模型，经验区间 10~40s",
    "retry_rate": "需人工重做的镜头比例，经验区间 5%~15%",
}


def build_tasks(cfg):
    """生成全部镜头任务：按 (剧, 集, 镜) 顺序。"""
    tasks = []
    for d in range(cfg["n_dramas"]):
        for e in range(cfg["n_episodes"]):
            for s in range(cfg["n_shots"]):
                tasks.append({"drama": d, "ep": e, "shot": s,
                              "idx": (d, e, s)})
    return tasks


def order_tasks(strategy, tasks, cfg):
    """按策略给出 GPU 队列的任务顺序。"""
    n_d = cfg["n_dramas"]
    if strategy == "serial":
        return list(tasks)                                  # 已是按剧分组顺序
    if strategy == "fifo":
        return sorted(tasks, key=lambda t: (t["ep"], t["shot"], t["drama"]))
    if strategy == "round_robin":
        by_drama = [[] for _ in range(n_d)]
        for t in tasks:
            by_drama[t["drama"]].append(t)
        out, i = [], 0
        while any(by_drama):
            for d in range(n_d):
                if by_drama[d]:
                    out.append(by_drama[d].pop(0))
            i += 1
        return out
    if strategy in ("batch_by_drama", "pipeline"):
        b = max(1, cfg["batch_size"])
        by_drama = [[] for _ in range(n_d)]
        for t in tasks:
            by_drama[t["drama"]].append(t)
        out = []
        # 每轮从每部剧取 b 个，兼顾"切换少"与"各剧进度均衡"
        while any(by_drama):
            for d in range(n_d):
                for _ in range(b):
                    if by_drama[d]:
                        out.append(by_drama[d].pop(0))
        return out
    raise ValueError("未知策略: " + strategy)


def simulate(strategy, cfg, seed=7):
    """离散事件模拟。返回指标字典。"""
    import random
    rng = random.Random(seed)
    tasks = order_tasks(strategy, build_tasks(cfg), cfg)
    n_d = cfg["n_dramas"]
    per_ep_shots = cfg["n_shots"]

    t_now = 0.0
    gpu_busy = 0.0
    switch_total = 0.0
    switch_count = 0
    loaded_drama = None

    # 冷启动
    t_now += cfg["model_load"]

    # CPU 侧：用最小堆管理完成时刻（pipeline 策略才重叠）
    cpu_heap = []
    cpu_slots = cfg["cpu_workers"]
    cpu_busy_time = 0.0

    first_ep_done = {}      # drama -> 首集完成时刻
    drama_done = {}         # drama -> 全部完成时刻
    ep_shot_count = {}      # (drama, ep) -> 已完成镜头数
    completed = 0
    total = len(tasks)

    overlap = (strategy == "pipeline")

    for t in tasks:
        d, e, s = t["idx"]

        # ---------- GPU 阶段 ----------
        if loaded_drama is None:
            loaded_drama = d
        elif loaded_drama != d:
            t_now += cfg["switch_cost"]
            switch_total += cfg["switch_cost"]
            switch_count += 1
            loaded_drama = d

        gpu_start = t_now
        gpu_dur = cfg["t_ref_img"] + cfg["t_video"]
        # 重试：按 retry_rate 概率追加一次视频生成
        if rng.random() < cfg["retry_rate"]:
            gpu_dur += cfg["t_video"]
        t_now = gpu_start + gpu_dur
        gpu_busy += gpu_dur

        # ---------- CPU 阶段 ----------
        cpu_dur = cfg["t_tts"] + cfg["t_mux"]
        cpu_busy_time += cpu_dur
        if overlap:
            # 有空闲 CPU 槽则立即开工，与后续 GPU 任务重叠
            if len(cpu_heap) >= cpu_slots:
                earliest = heapq.heappop(cpu_heap)
                if earliest > t_now:
                    t_now_cpu = earliest
                else:
                    t_now_cpu = t_now
            else:
                t_now_cpu = t_now
            heapq.heappush(cpu_heap, t_now_cpu + cpu_dur)
            finish = max(t_now, t_now_cpu + cpu_dur)
        else:
            # 非流水线：CPU 也串行跟在 GPU 后面
            t_now += cpu_dur
            finish = t_now

        completed += 1
        key = (d, e)
        ep_shot_count[key] = ep_shot_count.get(key, 0) + 1
        if ep_shot_count[key] == per_ep_shots:
            if d not in first_ep_done and e == 0:
                first_ep_done[d] = finish
            if (d, e) == (d, cfg["n_episodes"] - 1) and \
               ep_shot_count.get((d, cfg["n_episodes"] - 1), 0) == per_ep_shots:
                drama_done[d] = finish

    # 收尾：等待 CPU 队列排空
    while cpu_heap:
        t_now = max(t_now, heapq.heappop(cpu_heap))
    makespan = t_now

    # 若末集完成时刻未记录（并发下可能），用 makespan 兜底
    for d in range(n_d):
        if d not in drama_done:
            drama_done[d] = makespan
        if d not in first_ep_done:
            first_ep_done[d] = makespan

    total_shots = total
    return {
        "strategy": strategy,
        "makespan_h": makespan / 3600.0,
        "gpu_util": gpu_busy / makespan if makespan > 0 else 0,
        "switch_count": switch_count,
        "switch_cost_h": switch_total / 3600.0,
        "switch_overhead": switch_total / makespan if makespan > 0 else 0,
        "first_ep_h": statistics.mean(first_ep_done.values()) / 3600.0,
        "first_ep_max_h": max(first_ep_done.values()) / 3600.0,
        "drama_done_avg_h": statistics.mean(drama_done.values()) / 3600.0,
        "throughput_shots_per_h": total_shots / (makespan / 3600.0) if makespan else 0,
        "throughput_eps_per_day": (total_shots / per_ep_shots) /
                                  (makespan / 86400.0) if makespan else 0,
        "throughput_dramas_per_day": n_d / (makespan / 86400.0) if makespan else 0,
        "total_shots": total_shots,
    }


def main():
    ap = argparse.ArgumentParser(description="单设备多剧目并行吞吐调度模拟器")
    ap.add_argument("--config", help="JSON 配置文件（用你的实测值覆盖默认参数）")
    ap.add_argument("--dramas", type=int)
    ap.add_argument("--episodes", type=int)
    ap.add_argument("--shots", type=int)
    ap.add_argument("--t-video", type=float, help="单镜头视频生成秒数（实测）")
    ap.add_argument("--switch-cost", type=float, help="切换剧目的模型重载秒数（实测）")
    ap.add_argument("--cpu-workers", type=int)
    ap.add_argument("--batch-size", type=int)
    ap.add_argument("--json", help="导出 JSON")
    a = ap.parse_args()

    cfg = dict(DEFAULT)
    if a.config:
        with open(a.config, encoding="utf-8") as f:
            cfg.update(json.load(f))
    for k, v in (("n_dramas", a.dramas), ("n_episodes", a.episodes),
                 ("n_shots", a.shots), ("t_video", a.t_video),
                 ("switch_cost", a.switch_cost),
                 ("cpu_workers", a.cpu_workers),
                 ("batch_size", a.batch_size)):
        if v is not None:
            cfg[k] = v

    strategies = ["serial", "fifo", "round_robin", "batch_by_drama", "pipeline"]

    print("=" * 96)
    print(" 单设备多剧目并行 · 吞吐调度模拟器")
    print("=" * 96)
    print(f" 规模：{cfg['n_dramas']} 部剧 × {cfg['n_episodes']} 集 × "
          f"{cfg['n_shots']} 镜头 = "
          f"{cfg['n_dramas']*cfg['n_episodes']*cfg['n_shots']} 个镜头")
    print(f" 资源：{cfg['n_gpu']} GPU / {cfg['cpu_workers']} CPU 线程")
    print(f" 单镜头：GPU {cfg['t_ref_img']}+{cfg['t_video']}s，"
          f"CPU {cfg['t_tts']}+{cfg['t_mux']}s，切换代价 {cfg['switch_cost']}s")
    print(f" 冷启动 {cfg['model_load']}s，重试率 {cfg['retry_rate']:.0%}")
    print()
    print(" [!] 以上为示例参数，未经实测标定。结论仅用于比较策略间的相对关系。")

    rows = [simulate(s, cfg) for s in strategies]

    print("\n" + "=" * 96)
    print(" 策略对比")
    print("=" * 96)
    hdr = ["策略", "总完工h↓", "GPU利用率↑", "切换次数↓", "切换开销↓",
           "首集交付h↓", "单剧完成h↓", "镜头/小时↑"]
    print("  " + "".join(f"{h:>13s}" for h in hdr))
    for r in rows:
        print("  " + "".join([
            f"{r['strategy']:>13s}",
            f"{r['makespan_h']:>13.2f}",
            f"{r['gpu_util']*100:>12.1f}%",
            f"{r['switch_count']:>13d}",
            f"{r['switch_overhead']*100:>12.1f}%",
            f"{r['first_ep_h']:>13.2f}",
            f"{r['drama_done_avg_h']:>13.2f}",
            f"{r['throughput_shots_per_h']:>13.1f}",
        ]))

    base = next(r for r in rows if r["strategy"] == "serial")
    best_tp = max(rows, key=lambda r: r["throughput_shots_per_h"])
    best_fe = min(rows, key=lambda r: r["first_ep_h"])

    print("\n" + "-" * 96)
    tp_delta = best_tp["throughput_shots_per_h"] / base["throughput_shots_per_h"] - 1
    fe_delta = best_fe["first_ep_h"] / base["first_ep_h"] - 1
    print(f" 吞吐最优：{best_tp['strategy']}  "
          f"({best_tp['throughput_shots_per_h']:.1f} 镜头/小时，"
          f"相对串行 {tp_delta:+.1%})")
    print(f" 首集最快：{best_fe['strategy']}  "
          f"({best_fe['first_ep_h']:.2f} h，"
          f"相对串行 {fe_delta:+.1%})")

    print("\n 判读：")
    if best_tp["strategy"] == "serial":
        print("   · 在单 GPU 上，盲目并发并未提升总吞吐——GPU 算力恒定。")
        print("   · 大量切换剧目反而因模型重载而损失产能（见 round_robin 的切换开销）。")
    else:
        print(f"   · {best_tp['strategy']} 提升了总吞吐，说明切换代价可被 CPU 重叠抵消。")
    print("   · 但首集交付时间始终可通过并行大幅缩短——这才是「同时产出多部剧」的真正收益。")
    print("   · 若你的 KPI 是「一天出多少集」，看吞吐；若是「多久能交第一集」，看首集交付。")
    print("   · 继续提速的真正杠杆：降低 t_video（换更快的模型/量化/蒸馏）"
          " 与降低 switch_cost（模型常驻+显存池化），而不是单纯加并发。")

    if a.json:
        with open(a.json, "w", encoding="utf-8") as f:
            json.dump({"config": cfg, "results": rows}, f, ensure_ascii=False, indent=2)
        print(f"\n[OK] 导出 -> {a.json}")


if __name__ == "__main__":
    main()
