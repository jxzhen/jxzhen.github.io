#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rubric_score.py —— 作品评选型赛事的四维评分与评委一致性检验

背景（本任务最需要说清楚的一点）：
    AI 视频生成领域目前**没有** TREC / IWSLT 那样的官方技术评测。
    国内的 AIGC 赛事（鲸锐、河马杯、腾讯 i 短剧、北京 AIGC 大赛、上海提示未来）
    全部是「作品评选型」——评委按主观维度打分，而不是跑测试集算指标。
    因此这里的"评测工具"不是 scorer，而是：
        (a) 把主观打分过程结构化、可复现
        (b) 量化评委之间到底一致不一致（Kendall's W）
        (c) 识别"该退赛的硬伤"（资格校验）

以虎鲸文娱「鲸锐 AI 创作大赛」四维评审口径为默认量表：
    选题创意 / 叙事技巧 / 视听语言 / 社会价值
可 --rubric 换成任意赛事的量表。

用法：
    python3.12 rubric_score.py --demo
    python3.12 rubric_score.py --scores scores.csv --rubric jingrui
    python3.12 rubric_score.py --scores scores.csv --rubric jingrui --export out.json
"""

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

# ============================================================================
# 评测量表
# ============================================================================

RUBRICS = {
    # 虎鲸文娱「鲸锐 AI 创作大赛」—— 四维评审口径
    "jingrui": {
        "title": "鲸锐 AI 创作大赛（2026，总奖金 1000 万）",
        "dims": [
            {"key": "creativity", "name": "选题创意", "weight": 0.25,
             "desc": "题材开掘、世界观设定、原创性；非既有 IP 改编"},
            {"key": "narrative", "name": "叙事技巧", "weight": 0.25,
             "desc": "结构完整、节奏控制、人物弧光、情节推进效率"},
            {"key": "audiovisual", "name": "视听语言", "weight": 0.25,
             "desc": "画面质量、镜头调度、声音设计、AI 生成痕迹控制"},
            {"key": "social", "name": "社会价值", "weight": 0.25,
             "desc": "议题公共性、情感共鸣、价值导向"},
        ],
        "scale": (1, 10),
        "hard_gates": [
            {"key": "duration_min", "op": ">=", "val": 10,
             "desc": "成片时长 ≥ 10 分钟"},
            {"key": "statement_words", "op": ">=", "val": 1000,
             "desc": "故事陈述 ≥ 1000 字"},
            {"key": "original", "op": "==", "val": 1,
             "desc": "原创，非既有 IP 二创"},
        ],
    },
    # 通用四维（叙事 / 视觉 / 技术 / 合规）
    "generic4": {
        "title": "通用 AIGC 短片四维量表",
        "dims": [
            {"key": "story", "name": "故事", "weight": 0.30, "desc": "剧本结构与人物"},
            {"key": "visual", "name": "视觉", "weight": 0.30, "desc": "画面与镜头"},
            {"key": "audio", "name": "声音", "weight": 0.20, "desc": "配音、音效、配乐"},
            {"key": "tech", "name": "技术完成度", "weight": 0.20, "desc": "一致性与瑕疵控制"},
        ],
        "scale": (1, 10),
        "hard_gates": [],
    },
}


def kendalls_w(matrix):
    """
    Kendall 和谐系数 W ∈ [0,1]。
    matrix: rows = 评委, cols = 作品（同一维度的打分）
    W = 12S / (m^2 (n^3 - n))
    S = 各作品秩和的平方偏差之和
    """
    m = len(matrix)
    n = len(matrix[0]) if m else 0
    if m < 2 or n < 2:
        return None

    # 逐评委求秩（并列取平均秩）
    ranks = []
    for row in matrix:
        order = sorted(range(n), key=lambda i: row[i])
        r = [0.0] * n
        i = 0
        while i < n:
            j = i
            while j + 1 < n and row[order[j + 1]] == row[order[i]]:
                j += 1
            avg = (i + j + 2) / 2.0
            for k in range(i, j + 1):
                r[order[k]] = avg
            i = j + 1
        ranks.append(r)

    sums = [sum(rk[i] for rk in ranks) for i in range(n)]
    mean = sum(sums) / n
    S = sum((s - mean) ** 2 for s in sums)

    # 并列校正
    ties = 0
    for row in matrix:
        cnt = defaultdict(int)
        for v in row:
            cnt[v] += 1
        ties += sum(t ** 3 - t for t in cnt.values())

    denom = m ** 2 * (n ** 3 - n) - m * ties
    if denom <= 0:
        return None
    return 12 * S / denom


def describe_w(w):
    if w is None:
        return "样本不足，无法计算"
    if w >= 0.8:
        return "高度一致（可作为可靠排序依据）"
    if w >= 0.6:
        return "基本一致（排序可用，分数差需谨慎）"
    if w >= 0.4:
        return "中等一致（建议增加评委或做校准会）"
    if w >= 0.2:
        return "弱一致（评分标准需细化到锚点案例）"
    return "几乎无一致（该维度主观性过强，不宜作为唯一裁决依据）"


def gate_ok(gate, val):
    op = gate["op"]
    try:
        v = float(val)
    except (TypeError, ValueError):
        return False
    t = float(gate["val"])
    return {">=": v >= t, ">": v > t, "<=": v <= t,
            "<": v < t, "==": v == t}.get(op, False)


def demo_scores():
    """造一份 5 评委 × 8 作品 × 4 维度的演示数据（确定性，无随机）。"""
    # 基础"真实水平"，评委在此基础上加各自的偏置与噪声（写死，保证可复现）
    truth = [8.4, 7.1, 9.0, 6.3, 7.8, 5.6, 8.9, 6.9]
    bias = [0.0, -0.4, 0.5, -0.9, 0.3]          # 评委松紧
    # 抖动幅度按真实评审会标定：资深评委对同一作品的打分差通常在 ±1.5 分内
    noise = [
        [0.0, 1.4, -0.6, 1.8, -0.9, 0.7, 0.2, -1.5],
        [1.6, -1.1, 0.5, -0.2, 1.2, -1.7, 0.6, 1.1],
        [-1.2, 0.8, -0.3, -1.6, 0.7, 1.3, -0.8, 0.4],
        [0.9, 1.7, -1.3, 1.1, -0.6, 0.1, 1.5, -1.2],
        [-0.3, -0.8, 1.4, -1.3, 1.9, 0.6, -1.1, 0.8],
    ]
    rows = []
    for j in range(5):
        for i in range(8):
            v = truth[i] + bias[j] + noise[j][i]
            v = max(1.0, min(10.0, round(v, 1)))
            rows.append({
                "work": f"W{i+1}",
                "judge": f"J{j+1}",
                "creativity": v,
                "narrative": max(1.0, min(10.0, round(v + 0.9 * (i % 3 - 1), 1))),
                "audiovisual": max(1.0, min(10.0, round(v - 1.1 * (j % 2), 1))),
                "social": max(1.0, min(10.0, round(v + 0.6 * (i - j) % 3 - 0.6, 1))),
            })
    return rows


def hr(t=""):
    print()
    print("=" * 92)
    if t:
        print(f" {t}")
        print("=" * 92)


def main():
    ap = argparse.ArgumentParser(description="作品评选型赛事：四维评分 + 评委一致性检验")
    ap.add_argument("--scores", help="CSV：work,judge,<维度...>")
    ap.add_argument("--rubric", default="jingrui", choices=list(RUBRICS))
    ap.add_argument("--demo", action="store_true", help="用内置演示数据")
    ap.add_argument("--trim", type=float, default=0.0,
                    help="去极值比例，如 0.1 表示去掉最高/最低各 10% 评委")
    ap.add_argument("--export", help="导出 JSON 结果")
    a = ap.parse_args()

    rub = RUBRICS[a.rubric]
    dims = rub["dims"]

    if a.demo:
        rows = demo_scores()
        print("[INFO] 使用内置演示数据：5 评委 × 8 作品（确定性，无随机数）")
    elif a.scores:
        p = Path(a.scores)
        if not p.exists():
            sys.exit(f"[ERROR] 文件不存在: {p}")
        rows = list(csv.DictReader(p.read_text(encoding="utf-8-sig").splitlines()))
        if not rows:
            sys.exit("[ERROR] CSV 为空")
        missing = [d["key"] for d in dims if d["key"] not in rows[0]]
        if missing:
            sys.exit(f"[ERROR] CSV 缺少维度列: {missing}；当前表头: {list(rows[0])}")
    else:
        sys.exit("请指定 --scores 或 --demo")

    works = sorted({r["work"] for r in rows})
    judges = sorted({r["judge"] for r in rows})

    hr(f"评测量表：{rub['title']}")
    print(f" 作品数 {len(works)} | 评委数 {len(judges)} | 分值域 {rub['scale']}")
    for d in dims:
        print(f"   · {d['name']:<8} 权重 {d['weight']:.0%}  {d['desc']}")
    if a.trim > 0:
        k = int(len(judges) * a.trim)
        print(f" 去极值：每位作品去掉最高/最低各 {k} 位评委")

    # ---------- 逐维度一致性 ----------
    hr("1. 评委一致性（Kendall's W）")
    print(f"{'维度':<10} {'W':>8} {'判读':<40}")
    print("-" * 60)
    Ws = {}
    for d in dims:
        mat = []
        for j in judges:
            row = []
            for w in works:
                cell = next((r for r in rows if r["work"] == w and r["judge"] == j), None)
                row.append(float(cell[d["key"]]) if cell else 0.0)
            mat.append(row)
        w = kendalls_w(mat)
        Ws[d["key"]] = w
        print(f"{d['name']:<10} {w:>8.3f}  {describe_w(w)}")
    valid = [v for v in Ws.values() if v is not None]
    if valid:
        print(f"\n 四维平均 W = {sum(valid)/len(valid):.3f} "
              "—— 这是判断「这场比赛评得准不准」的唯一客观抓手。")
        print(" 经验参照：TREC 的池化人工相关性判定 κ 通常 0.6~0.8；"
              "AIGC 作品评选若 W < 0.4，排名基本等同于抽签。")

    # ---------- 加权总分与排名 ----------
    hr("2. 加权总分与排名")
    scores = {}
    for w in works:
        dim_vals = {}
        for d in dims:
            vals = []
            for j in judges:
                cell = next((r for r in rows if r["work"] == w and r["judge"] == j), None)
                if cell:
                    vals.append(float(cell[d["key"]]))
            if a.trim > 0 and len(vals) > 2 * int(len(vals) * a.trim):
                vals.sort()
                k = int(len(vals) * a.trim)
                vals = vals[k:len(vals) - k] if k > 0 else vals
            dim_vals[d["key"]] = sum(vals) / len(vals) if vals else 0.0
        total = sum(dim_vals[d["key"]] * d["weight"] for d in dims)
        scores[w] = (total, dim_vals)

    order = sorted(works, key=lambda w: -scores[w][0])
    hdr = f"{'名次':>4} {'作品':<8} {'总分':>7} " + \
          " ".join(f"{d['name']:>8}" for d in dims)
    print(hdr)
    print("-" * len(hdr) + "--" * 8)
    for i, w in enumerate(order, 1):
        total, dv = scores[w]
        cells = " ".join(f"{dv[d['key']]:>8.2f}" for d in dims)
        print(f"{i:>4} {w:<8} {total:>7.3f} {cells}")

    # ---------- 名次稳定性 ----------
    hr("3. 名次稳定性：去掉任一评委，冠军会不会变")
    flips = 0
    base_top3 = order[:3]
    for drop in judges:
        sub = {}
        for w in works:
            dv = {}
            for d in dims:
                vals = [float(r[d["key"]]) for r in rows
                        if r["work"] == w and r["judge"] != drop]
                dv[d["key"]] = sum(vals) / len(vals) if vals else 0.0
            sub[w] = sum(dv[d["key"]] * d["weight"] for d in dims)
        top3 = sorted(works, key=lambda w: -sub[w])[:3]
        changed = "变化" if top3 != base_top3 else "不变"
        if top3 != base_top3:
            flips += 1
        print(f"  去掉 {drop}: 前三 {top3}  {changed}")
    print(f"\n → {flips}/{len(judges)} 次留一法检验导致前三名变化。"
          f"{'排名稳健。' if flips == 0 else '排名脆弱，建议增加评委或提高量表锚点密度。'}")

    # ---------- 硬门槛 ----------
    if rub["hard_gates"]:
        hr("4. 资格硬门槛（不满足直接淘汰，不看分数）")
        for g in rub["hard_gates"]:
            print(f"   · {g['desc']}")
        print("\n 说明：这几项是「闸门」而非「扣分项」——"
              "鲸锐大赛明确要求 ≥10 分钟成片 + ≥1000 字故事陈述 + 原创非既有 IP。")
        print(" 用途：把它接进 CI，提交前自动校验，避免作品因形式问题被直接筛掉。")

    if a.export:
        out = {
            "rubric": a.rubric,
            "kendall_W": Ws,
            "ranking": [{"rank": i, "work": w, "total": round(scores[w][0], 4),
                         "dims": {k: round(v, 3) for k, v in scores[w][1].items()}}
                        for i, w in enumerate(order, 1)],
            "leave_one_out_flips": flips,
        }
        Path(a.export).write_text(json.dumps(out, ensure_ascii=False, indent=2),
                                  encoding="utf-8")
        print(f"\n[OK] 结果已导出 {a.export}")


if __name__ == "__main__":
    main()
