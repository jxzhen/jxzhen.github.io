#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
plan_production.py —— 单机多剧产能规划器

回答用户的核心问题：
    "我有一台设备，能不能同时跑 N 部剧？N 的上限是多少？"

与 throughput_sim.py 的分工：
    throughput_sim.py   —— 给定 N 部剧，用离散事件模拟各种调度策略的完工时间
    plan_production.py  —— 反过来：给定设备与工期要求，反解"最多能并行几部剧"

模型要点（都是"可证伪"的显式假设，全部可用 --config 覆盖）：
    1. 显存墙（硬约束）
       一部剧的工作集 = 常驻模型 + 参考图缓存 + 单镜头激活显存
       RTX 4090 24GB 无 NVLink：多卡 ≠ 统一显存，4×24GB 不是 96GB 可用单实例
       因此"单卡可并行剧目数" = floor((VRAM - reserve) / working_set_per_drama)
    2. 时间墙（软约束）
       总 GPU 工时 = 剧目数 × 每剧集数 × 每集镜头数 × 单镜头 GPU 秒数 × (1 + 重试率)
       工期 = 总 GPU 工时 / (卡数 × 单卡并行度 × GPU 利用率)
    3. 切换墙（效率约束）
       换剧要换 LoRA / 参考图 / 提示词模板，产生换入换出开销
       并行度越高，切换越频繁，利用率越低 —— 存在边际收益拐点

用法：
    python3.12 plan_production.py                       # 默认：2 卡 RTX 4090
    python3.12 plan_production.py --gpus 4 --vram 24
    python3.12 plan_production.py --config my.json
    python3.12 plan_production.py --deadline-days 7     # 反解：7 天工期能跑几部
"""

import argparse
import json
import math
import sys
from pathlib import Path

# ============================================================================
# 默认参数 —— 全部为"示例值"，必须用自己的实测数据替换
# 之所以写死在这里而不是藏起来，是为了让每个数字都可被质疑、可被替换
# ============================================================================

DEFAULTS = {
    # ---- 设备 ----
    "gpus": 2,                    # GPU 卡数
    "vram_gb": 24,                # 单卡显存 GB
    "vram_reserve_gb": 2.0,       # 驱动/系统/碎片预留
    "has_nvlink": False,          # 4090 无 NVLink；A100/H100 有

    # ---- 单部剧的显存工作集（GB）----
    # 以 SDXL + IP-Adapter + AnimateDiff 类流水线为参照
    "vram_base_model_gb": 6.5,    # 常驻底模（fp16）
    "vram_lora_gb": 0.4,          # 角色 LoRA
    "vram_refimg_cache_gb": 1.2,  # 参考图/角色一致性缓存
    "vram_activation_gb": 3.5,    # 单镜头推理激活显存（随分辨率/帧数增长）
    "vram_shared_gb": 1.8,        # 多剧共享部分（VAE/CLIP/文本编码器），只算一次

    # ---- 单镜头耗时（秒）----
    "t_ref_img_s": 25.0,          # 参考图/角色定妆（GPU）
    "t_video_s": 110.0,           # 视频生成主体（GPU，大头）
    "t_tts_s": 12.0,              # 配音合成（CPU，可与 GPU 重叠）
    "t_mux_s": 8.0,               # 封装/合流（CPU，可与 GPU 重叠）

    # ---- 效率 ----
    "switch_cost_s": 45.0,        # 换剧开销（换 LoRA + 重建缓存）
    "retry_rate": 0.18,           # 废片率/重做率（AI 生成必须计入）
    "gpu_util": 0.82,             # 单卡实际利用率（含 IO 等待、CPU 阻塞）
    "cpu_overlap": 0.85,          # CPU 阶段能与 GPU 重叠的比例

    # ---- 剧目规格 ----
    "dramas": 3,                  # 目标：同时推进几部剧
    "episodes_per_drama": 1,      # 每部剧的集数（先做首集）
    "shots_per_episode": 60,      # 每集镜头数
    "shot_duration_s": 5.0,       # 每镜头成片时长（秒）

    # ---- 工期 ----
    "deadline_days": None,        # 若给定，则反解最大并行剧目数
    "work_hours_per_day": 20.0,   # 每天有效机时（留 4h 维护/散热/排错）
}


def load_config(path):
    cfg = dict(DEFAULTS)
    if path:
        p = Path(path)
        if not p.exists():
            sys.exit(f"[ERROR] 配置文件不存在: {p}")
        cfg.update(json.loads(p.read_text(encoding="utf-8")))
    return cfg


def vram_budget(cfg):
    """单卡上最多能常驻几部剧 —— 显存墙给出的硬上限。"""
    usable = cfg["vram_gb"] - cfg["vram_reserve_gb"] - cfg["vram_shared_gb"]
    per_drama = (
        cfg["vram_base_model_gb"]
        + cfg["vram_lora_gb"]
        + cfg["vram_refimg_cache_gb"]
        + cfg["vram_activation_gb"]
    )
    n = int(usable // per_drama) if per_drama > 0 else 0
    return max(0, n), usable, per_drama


def gpu_seconds_per_shot(cfg):
    """单镜头 GPU 工时（含重做）。"""
    base = cfg["t_ref_img_s"] + cfg["t_video_s"]
    return base * (1.0 + cfg["retry_rate"])


def cpu_seconds_per_shot(cfg):
    base = cfg["t_tts_s"] + cfg["t_mux_s"]
    # 未重叠部分要额外占用墙钟时间
    return base * (1.0 - cfg["cpu_overlap"])


def estimate(cfg, n_dramas):
    """给定并行剧目数，估算工期与各项代价。"""
    shots = n_dramas * cfg["episodes_per_drama"] * cfg["shots_per_episode"]
    gpu_s = shots * gpu_seconds_per_shot(cfg)
    cpu_s = shots * cpu_seconds_per_shot(cfg)

    # 切换次数：batch_by_drama 策略下每剧每集切一次；这里按"每部剧一个批次"估
    switches = max(0, n_dramas - 1)
    switch_s = switches * cfg["switch_cost_s"]

    # 并行度：显存墙决定的并发槽位 × 卡数
    slots_per_card, _, _ = vram_budget(cfg)
    slots = max(1, slots_per_card * cfg["gpus"])

    # 有效并发 = min(剧目数, 槽位数)；超出部分要排队，不产生加速
    eff = min(n_dramas, slots)

    # GPU 侧墙钟：总工时 / 有效并发 / 利用率
    gpu_wall_s = gpu_s / (eff * cfg["gpu_util"]) if eff > 0 else float("inf")
    # CPU 侧无法被 GPU 遮蔽的部分，串行累加
    total_wall_s = gpu_wall_s * eff / max(1, eff) + switch_s + cpu_s / cfg["gpus"]
    # 更直白地写：
    total_wall_s = gpu_wall_s + switch_s + cpu_s / max(1, cfg["gpus"])

    hours = total_wall_s / 3600.0
    days = hours / cfg["work_hours_per_day"]

    # 单剧首集交付（batch_by_drama 下：先跑完一部剧的第一集）
    per_drama_shots = cfg["episodes_per_drama"] * cfg["shots_per_episode"]
    first_ep_s = per_drama_shots * gpu_seconds_per_shot(cfg) / cfg["gpu_util"]
    first_ep_s += per_drama_shots * cpu_seconds_per_shot(cfg)

    throughput = shots / (hours * cfg["work_hours_per_day"] / cfg["work_hours_per_day"]) \
        if hours > 0 else 0.0
    throughput = shots / hours if hours > 0 else 0.0

    # 成片总时长（分钟）
    runtime_min = n_dramas * cfg["episodes_per_drama"] * cfg["shots_per_episode"] \
        * cfg["shot_duration_s"] / 60.0

    return {
        "n_dramas": n_dramas,
        "slots": slots,
        "eff_concurrency": eff,
        "queued": max(0, n_dramas - slots),
        "shots": shots,
        "gpu_hours": gpu_s / 3600.0,
        "switch_hours": switch_s / 3600.0,
        "wall_hours": hours,
        "wall_days": days,
        "first_ep_hours": first_ep_s / 3600.0,
        "throughput_shots_per_h": throughput,
        "runtime_min": runtime_min,
        "gpu_util_eff": gpu_s / (total_wall_s * eff * cfg["gpu_util"]) if total_wall_s > 0 else 0,
    }


def solve_max_dramas(cfg, deadline_days):
    """反解：给定工期，最多能并行几部剧（受显存墙约束后取可行解）。"""
    budget_h = deadline_days * cfg["work_hours_per_day"]
    slots_per_card, _, _ = vram_budget(cfg)
    hard_cap = slots_per_card * cfg["gpus"]
    best = 0
    for n in range(1, 200):
        r = estimate(cfg, n)
        if r["wall_hours"] <= budget_h:
            best = n
        else:
            break
    return best, hard_cap


def hr(title=""):
    print()
    print("=" * 92)
    if title:
        print(f" {title}")
        print("=" * 92)


def main():
    ap = argparse.ArgumentParser(
        description="单机多剧产能规划器：反解一台设备最多能同时跑几部 AI 剧")
    ap.add_argument("--config", help="JSON 配置文件，覆盖默认参数")
    ap.add_argument("--gpus", type=int)
    ap.add_argument("--vram", type=float, dest="vram_gb")
    ap.add_argument("--dramas", type=int)
    ap.add_argument("--shots", type=int, dest="shots_per_episode")
    ap.add_argument("--t-video", type=float, dest="t_video_s")
    ap.add_argument("--deadline-days", type=float, help="给定工期（天），反解最大并行剧目数")
    ap.add_argument("--dump-config", help="把当前默认参数导出为 JSON 供修改")
    a = ap.parse_args()

    cfg = load_config(a.config)
    for k in ("gpus", "vram_gb", "dramas", "shots_per_episode", "t_video_s"):
        v = getattr(a, k, None)
        if v is not None:
            cfg[k] = v
    if a.deadline_days is not None:
        cfg["deadline_days"] = a.deadline_days

    if a.dump_config:
        Path(a.dump_config).write_text(
            json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[OK] 默认参数已导出到 {a.dump_config}，改完用 --config 载入")
        return

    # ---------- 1. 显存墙 ----------
    hr("1. 显存墙：单卡能常驻几部剧（硬约束）")
    n_card, usable, per_drama = vram_budget(cfg)
    print(f" 单卡显存               : {cfg['vram_gb']:.1f} GB"
          f"{'（有 NVLink）' if cfg['has_nvlink'] else '（无 NVLink，多卡不共享显存）'}")
    print(f" 扣除共享({cfg['vram_shared_gb']}GB)+预留({cfg['vram_reserve_gb']}GB)"
          f" 后可用 : {usable:.2f} GB")
    print(f" 单部剧工作集           : {per_drama:.2f} GB"
          f"  = 底模 {cfg['vram_base_model_gb']} + LoRA {cfg['vram_lora_gb']}"
          f" + 参考图 {cfg['vram_refimg_cache_gb']} + 激活 {cfg['vram_activation_gb']}")
    print(f" → 单卡可常驻剧目数     : {n_card} 部")
    print(f" → 整机槽位数（{cfg['gpus']} 卡）: {n_card * cfg['gpus']} 个")
    if n_card == 0:
        print("\n [警告] 显存不足，单卡连一部剧都放不下，必须先做模型量化/切分：")
        print("   · 底模改 fp8 / GGUF Q5_K_M（6.5GB → 约 3.5GB）")
        print("   · 关闭参考图常驻，改为按需加载")
        print("   · 降低单镜头分辨率或帧数（直接砍 vram_activation_gb）")

    # ---------- 2. 时间墙 ----------
    hr("2. 时间墙：不同并行度下的工期")
    print(f" 单镜头 GPU 工时        : {gpu_seconds_per_shot(cfg):.1f} s"
          f"（含 {cfg['retry_rate']:.0%} 重做率）")
    print(f" 单镜头不可重叠 CPU     : {cpu_seconds_per_shot(cfg):.1f} s")
    print(f" 换剧开销               : {cfg['switch_cost_s']:.0f} s/次")
    print()
    hdr = (f"{'并行剧数':>8} {'并发槽位':>8} {'排队':>6} {'镜头数':>8} "
           f"{'GPU工时h':>9} {'切换h':>7} {'工期h':>8} {'工期天':>7} "
           f"{'首集h':>7} {'镜头/时':>8} {'成片min':>8}")
    print(hdr)
    print("-" * len(hdr) + "-" * 20)
    slots = max(1, n_card * cfg["gpus"])
    rows = []
    for n in range(1, max(cfg["dramas"], slots) + 5):
        r = estimate(cfg, n)
        rows.append(r)
        mark = " ← 目标" if n == cfg["dramas"] else ""
        print(f"{r['n_dramas']:>8} {r['slots']:>8} {r['queued']:>6} {r['shots']:>8} "
              f"{r['gpu_hours']:>9.2f} {r['switch_hours']:>7.2f} "
              f"{r['wall_hours']:>8.2f} {r['wall_days']:>7.2f} "
              f"{r['first_ep_hours']:>7.2f} {r['throughput_shots_per_h']:>8.1f} "
              f"{r['runtime_min']:>8.1f}{mark}")

    # ---------- 3. 边际收益拐点 ----------
    hr("3. 边际收益拐点：加到第几部开始不划算")
    print(" 判据：每多并行一部剧，'单镜头摊薄工期'下降多少。跌幅 < 3% 即视为饱和。")
    print()
    prev = None
    saturated_at = None
    for r in rows:
        per_shot_h = r["wall_hours"] / r["shots"] if r["shots"] else 0
        if prev is None:
            print(f"  并行 {r['n_dramas']} 部: 单镜头摊薄 {per_shot_h*60:.2f} 分钟  (基准)")
        else:
            gain = prev / per_shot_h - 1 if per_shot_h > 0 else 0
            flag = ""
            if gain < 0.03 and saturated_at is None:
                saturated_at = r["n_dramas"]
                flag = "  ← 饱和"
            print(f"  并行 {r['n_dramas']} 部: 单镜头摊薄 {per_shot_h*60:.2f} 分钟"
                  f"  较上一档 {gain:+.1%}{flag}")
        prev = per_shot_h
    if saturated_at:
        print(f"\n → 并行度超过 {saturated_at - 1} 部后，单镜头摊薄工期不再下降（已饱和）。")
        print(f"   注意：饱和点 {saturated_at - 1} 部正好等于显存槽位数 {slots} ——"
              f"这说明拐点由**显存**决定，不是由调度算法决定。")
        print(f"   含义：{slots} 部以内加并行是白拿的收益；"
              f"超过 {slots} 部只是在排队，总吞吐不再提升。")
        print(f"   再想提速应改杠杆：降 t_video（更快模型/量化/蒸馏）、"
              f"降 switch_cost（模型常驻+显存池化）、扩显存槽位，而不是继续加并行。")
    else:
        print("\n → 在考察范围内尚未饱和，可继续加并行（但仍受显存槽位硬顶约束）。")

    # ---------- 4. 反解 ----------
    if cfg.get("deadline_days"):
        d = cfg["deadline_days"]
        best, hard = solve_max_dramas(cfg, d)
        hr(f"4. 反解：{d:g} 天工期内最多能交付几部剧")
        print(f" 每天有效机时           : {cfg['work_hours_per_day']:.1f} h")
        print(f" 总预算机时             : {d * cfg['work_hours_per_day']:.1f} h")

        # 关键区分：同时并行数（显存墙） vs 工期内累计交付数（时间墙）
        concurrent = min(cfg["dramas"] if cfg["dramas"] else hard, hard)
        print(f" 显存决定的**同时**并行上限 : {hard} 部（超过就只是排队，不提速）")
        print(f" → {d:g} 天内**累计**可交付   : {best} 部（分批跑完，不是同时跑）")
        if best == 0:
            print("\n [结论] 当前配置下一部都交不了，必须先降 t_video 或加卡。")
        else:
            batches = math.ceil(best / hard) if hard > 0 else 0
            print(f"\n [结论] 分 {batches} 批交付，每批同时推进 {hard} 部。")
            print(f"   这一条直接回答「一台设备能不能同时出多部剧」：能，但同时数是 "
                  f"{hard} 部，由显存钉死；")
            print(f"   「一天出多少部」是 {best / d:.1f} 部/天，由单镜头耗时与废片率决定。")
            print(f"   想让前者变大：压缩单剧工作集（量化/共享底座/按需加载参考图）。")
            print(f"   想让后者变大：降 t_video、降 retry_rate，或加卡。")

    # ---------- 5. 工程建议 ----------
    hr("5. 落地建议（对应上面的数字，不是空话）")
    print(" · 一张卡起一个 ComfyUI 实例，各自绑端口（8188/8189/...），"
          "由一个 Python 调度器分发任务；不要把多卡塞进一个实例。")
    print(" · 角色 LoRA / 参考图按剧做缓存池，同剧镜头连续排产，"
          "把 switch_cost 摊到每剧一次而不是每镜头一次。")
    print(" · TTS 与合流放 CPU，与 GPU 推理流水线重叠（本模型已按 "
          f"{cfg['cpu_overlap']:.0%} 重叠率计算）。")
    print(" · 上式所有数字都是示例值。请先用 --dump-config 导出，"
          "拿你自己的实测 t_video / 废片率 / 显存占用回填，结论才可信。")


if __name__ == "__main__":
    main()
