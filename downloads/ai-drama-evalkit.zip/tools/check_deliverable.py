#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_deliverable.py —— AI 剧目交付物提交前体检（对标 TREC 的 check_format.py）

定位：
    TREC 用 check_format.py 在提交 run 文件前拦截格式错误；
    本工具在提交 AI 剧目作品前拦截"会被直接筛掉"的硬伤。

三类检查：
    [A] 资格闸门 —— 赛事明文规定的硬条件（时长、字数、原创性）
    [B] 技术规格 —— 分辨率 / 帧率 / 音轨 / 时长一致性
    [C] 字幕合规 —— CPS（每秒字符数）/ CPL（每行字符数）/ LPB（行数）
                     沿用 IWSLT 2026 字幕口径（中文 CPS<=9、CPL<=16、LPB<=2）

ffprobe 可选：存在则真实探测；不存在则按 --declare-* 声明值做纯文本校验，
并明确标注「未实测」——不许把声明值伪装成实测值。

用法：
    python3.12 check_deliverable.py --demo
    python3.12 check_deliverable.py --video a.mp4 --srt a.srt --statement story.txt
    python3.12 check_deliverable.py --video a.mp4 --rule hema
"""

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# 赛事规则表
# ---------------------------------------------------------------------------

RULES = {
    "jingrui": {  # 虎鲸文娱「鲸锐 AI 创作大赛」2026
        "name": "鲸锐 AI 创作大赛（总奖金 1000 万）",
        "min_duration_min": 10,
        "min_statement_words": 1000,
        "original_required": True,
        "min_width": 1280,
        "min_height": 720,
        "min_fps": 24,
        "min_audio_bitrate_kbps": 96,
    },
    "hema": {  # 河马杯微短剧（第 20 届中国好创意 AIGC 赛道）
        "name": "河马杯微短剧创作大赛",
        "min_duration_min": 1,
        "min_statement_words": 0,
        "original_required": True,
        "min_width": 1080,
        "min_height": 1920,
        "min_fps": 25,
        "min_audio_bitrate_kbps": 96,
    },
    "generic": {
        "name": "通用短剧交付",
        "min_duration_min": 5,
        "min_statement_words": 300,
        "original_required": True,
        "min_width": 1280,
        "min_height": 720,
        "min_fps": 24,
        "min_audio_bitrate_kbps": 64,
    },
}

# 字幕合规阈值（中文口径源自 IWSLT 2026 对 zh 的规定）
SUBTITLE_LIMITS = {
    "zh": {"cps": 9, "cpl": 16, "lpb": 2},
    "en": {"cps": 21, "cpl": 42, "lpb": 2},
    "ja": {"cps": 9, "cpl": 16, "lpb": 2},
    "ko": {"cps": 12, "cpl": 20, "lpb": 2},
}


def hr(t=""):
    print()
    print("=" * 92)
    if t:
        print(f" {t}")
        print("=" * 92)


def count_words_cn(text):
    """中文字数：汉字按字计，西文按词计，标点不计。"""
    han = len(re.findall(r"[\u4e00-\u9fff]", text))
    west = len(re.findall(r"[A-Za-z0-9]+", text))
    return han + west


def count_words_en(text):
    return len(re.findall(r"[A-Za-z0-9]+", text))


def ffprobe_info(path):
    """返回 dict 或 None（ffprobe 不存在 / 解析失败）。"""
    if not shutil.which("ffprobe"):
        return None
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-print_format", "json",
             "-show_format", "-show_streams", str(path)],
            capture_output=True, text=True, timeout=30)
        if out.returncode != 0:
            return None
        return json.loads(out.stdout)
    except Exception:
        return None


def parse_fps(rate):
    try:
        if "/" in rate:
            a, b = rate.split("/")
            return float(a) / float(b) if float(b) else 0.0
        return float(rate)
    except Exception:
        return 0.0


def parse_srt(text):
    """返回 [(start_s, end_s, [line,...]), ...]；失败抛 ValueError。"""
    blocks = re.split(r"\n\s*\n", text.replace("\r\n", "\n").strip())
    out = []
    for b in blocks:
        lines = [l for l in b.split("\n") if l.strip() != ""]
        if len(lines) < 2:
            continue
        m = re.match(
            r"(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*"
            r"(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})", lines[1] if len(lines) > 1 else "")
        if not m:
            # 有些文件首行是序号，时间轴在第二行；再试第一行
            m = re.match(
                r"(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*"
                r"(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})", lines[0])
            if not m:
                raise ValueError(f"无法解析时间轴：{lines[0][:60]!r}")
            text_lines = lines[1:]
        else:
            text_lines = lines[2:]
        h1, m1, s1, ms1, h2, m2, s2, ms2 = map(int, m.groups())
        st = h1 * 3600 + m1 * 60 + s1 + ms1 / 1000.0
        et = h2 * 3600 + m2 * 60 + s2 + ms2 / 1000.0
        out.append((st, et, [l for l in text_lines if l.strip()]))
    if not out:
        raise ValueError("SRT 中未解析到任何字幕块")
    return out


def check_subtitle(cues, lang):
    lim = SUBTITLE_LIMITS.get(lang, SUBTITLE_LIMITS["zh"])
    issues = []
    cps_max = cpl_max = lpb_max = 0.0
    n_bad_cps = n_bad_cpl = n_bad_lpb = 0
    n_overlap = n_nonmono = n_tooshort = 0

    prev_end = -1.0
    for i, (st, et, lines) in enumerate(cues, 1):
        dur = et - st
        joined = "".join(lines)
        # 中文按字符数；西文按字符数亦可近似（CPL 本就是字符口径）
        nchar = len(joined.replace(" ", ""))
        cps = nchar / dur if dur > 0 else float("inf")
        cpl = max((len(l.replace(" ", "")) for l in lines), default=0)
        lpb = len(lines)
        cps_max = max(cps_max, cps)
        cpl_max = max(cpl_max, cpl)
        lpb_max = max(lpb_max, lpb)

        if cps > lim["cps"]:
            n_bad_cps += 1
        if cpl > lim["cpl"]:
            n_bad_cpl += 1
        if lpb > lim["lpb"]:
            n_bad_lpb += 1
        if dur < 0.5:
            n_tooshort += 1
        if st < prev_end - 1e-6:
            n_overlap += 1
        if et < st:
            n_nonmono += 1
        prev_end = max(prev_end, et)

    if n_bad_cps:
        issues.append(f"CPS 超标 {n_bad_cps} 条（阈值 {lim['cps']}，实测峰值 {cps_max:.1f}）")
    if n_bad_cpl:
        issues.append(f"CPL 超标 {n_bad_cpl} 条（阈值 {lim['cpl']}，实测峰值 {cpl_max:.0f}）")
    if n_bad_lpb:
        issues.append(f"LPB 超标 {n_bad_lpb} 条（阈值 {lim['lpb']}，实测峰值 {lpb_max:.0f}）")
    if n_tooshort:
        issues.append(f"停留过短（<0.5s）{n_tooshort} 条，观众读不完")
    if n_overlap:
        issues.append(f"时间轴重叠 {n_overlap} 条")
    if n_nonmono:
        issues.append(f"结束早于开始 {n_nonmono} 条")

    return {
        "n_cues": len(cues),
        "cps_max": cps_max, "cpl_max": cpl_max, "lpb_max": lpb_max,
        "limits": lim,
        "n_bad_cps": n_bad_cps, "n_bad_cpl": n_bad_cpl, "n_bad_lpb": n_bad_lpb,
        "n_overlap": n_overlap, "n_nonmono": n_nonmono, "n_tooshort": n_tooshort,
        "issues": issues,
    }


def main():
    ap = argparse.ArgumentParser(description="AI 剧目交付物提交前体检")
    ap.add_argument("--video", help="成片文件（mp4/mov 等）")
    ap.add_argument("--srt", help="字幕文件")
    ap.add_argument("--statement", help="故事陈述（txt/md）")
    ap.add_argument("--rule", default="jingrui", choices=list(RULES))
    ap.add_argument("--lang", default="zh", choices=list(SUBTITLE_LIMITS))
    ap.add_argument("--declare-duration-min", type=float, help="无 ffprobe 时声明时长（分钟）")
    ap.add_argument("--declare-width", type=int)
    ap.add_argument("--declare-height", type=int)
    ap.add_argument("--declare-fps", type=float)
    ap.add_argument("--original", action="store_true", help="声明为原创非既有 IP")
    ap.add_argument("--demo", action="store_true", help="内置演示（含一处故意的不合格）")
    ap.add_argument("--export", help="导出 JSON")
    a = ap.parse_args()

    rule = RULES[a.rule]
    problems, warnings, oks = [], [], []

    hr(f"赛事规则：{rule['name']}")
    print(f" 成片时长 ≥ {rule['min_duration_min']} 分钟")
    print(f" 故事陈述 ≥ {rule['min_statement_words']} 字")
    print(f" 分辨率 ≥ {rule['min_width']}×{rule['min_height']}，帧率 ≥ {rule['min_fps']} fps")
    print(f" 原创要求：{'必须原创，非既有 IP 二创' if rule['original_required'] else '无'}")

    # ================= [A] 资格闸门 =================
    hr("[A] 资格闸门")

    # A1 原创性
    if rule["original_required"]:
        if a.original:
            oks.append("原创性：已声明原创（请自行留存创作过程留痕，赛事可能要求举证）")
        else:
            problems.append("原创性：未声明。未加 --original 视为不满足，"
                            "赛事明文要求「非既有 IP」")
    # A2 时长
    dur_min, dur_src = None, None
    if a.video and Path(a.video).exists():
        info = ffprobe_info(a.video)
        if info:
            try:
                dur_min = float(info["format"]["duration"]) / 60.0
                dur_src = "ffprobe 实测"
            except Exception:
                dur_min, dur_src = None, None
        if dur_min is None:
            dur_min, dur_src = a.declare_duration_min, "命令行声明（未实测）"
    elif a.declare_duration_min is not None:
        dur_min, dur_src = a.declare_duration_min, "命令行声明（未实测）"

    if dur_min is None:
        warnings.append("时长：未提供视频/声明值，无法校验"
                        f"（赛事要求 ≥ {rule['min_duration_min']} 分钟）")
    else:
        ok = dur_min >= rule["min_duration_min"]
        line = f"时长：{dur_min:.2f} 分钟（{dur_src}）"
        (oks if ok else problems).append(
            line + ("" if ok else f" —— 不足 {rule['min_duration_min']} 分钟，直接淘汰"))

    # A3 故事陈述字数
    st_words, st_src = None, None
    if a.statement and Path(a.statement).exists():
        txt = Path(a.statement).read_text(encoding="utf-8-sig", errors="replace")
        st_words = count_words_cn(txt)
        st_src = f"实测（{Path(a.statement).name}）"
    if st_words is None:
        warnings.append(f"故事陈述：未提供文件，无法校验"
                        f"（赛事要求 ≥ {rule['min_statement_words']} 字）")
    else:
        ok = st_words >= rule["min_statement_words"]
        line = f"故事陈述：{st_words} 字（{st_src}）"
        (oks if ok else problems).append(
            line + ("" if ok else f" —— 不足 {rule['min_statement_words']} 字，直接淘汰"))

    # ================= [B] 技术规格 =================
    hr("[B] 技术规格")
    if a.video and Path(a.video).exists():
        info = ffprobe_info(a.video)
        if info is None:
            warnings.append("未找到 ffprobe，改用声明值做纯文本校验，"
                            "分辨率/帧率/音轨**未实测**")
            w, h, fps = a.declare_width, a.declare_height, a.declare_fps
            src = "声明"
        else:
            vs = next((s for s in info.get("streams", [])
                       if s.get("codec_type") == "video"), None)
            aus = [s for s in info.get("streams", [])
                   if s.get("codec_type") == "audio"]
            w = vs.get("width") if vs else None
            h = vs.get("height") if vs else None
            fps = parse_fps(vs.get("r_frame_rate", "0")) if vs else None
            src = "ffprobe 实测"
            if not aus:
                problems.append("音轨：未检测到音频流 —— 无声片在作品评选中基本等于弃赛")
            else:
                br = aus[0].get("bit_rate")
                kb = int(br) / 1000 if br else None
                if kb and kb < rule["min_audio_bitrate_kbps"]:
                    problems.append(f"音轨码率：{kb:.0f} kbps 低于 "
                                    f"{rule['min_audio_bitrate_kbps']} kbps")
                else:
                    oks.append(f"音轨：{len(aus)} 条"
                               + (f"，{kb:.0f} kbps" if kb else ""))
        for label, val, lim in (("宽度", w, rule["min_width"]),
                                ("高度", h, rule["min_height"]),
                                ("帧率", fps, rule["min_fps"])):
            if val is None:
                warnings.append(f"{label}：未提供，无法校验（要求 ≥ {lim}）")
            else:
                ok = val >= lim
                (oks if ok else problems).append(
                    f"{label}：{val:g}（{src}）"
                    + ("" if ok else f" —— 低于要求 {lim}"))
    else:
        warnings.append("未提供视频文件，[B] 技术规格整体跳过")

    # ================= [C] 字幕合规 =================
    hr("[C] 字幕合规（IWSLT 口径）")
    sub = None
    srt_path = a.srt
    if a.demo:
        srt_path = None
    if srt_path and Path(srt_path).exists():
        try:
            cues = parse_srt(Path(srt_path).read_text(encoding="utf-8-sig",
                                                      errors="replace"))
            sub = check_subtitle(cues, a.lang)
        except ValueError as e:
            problems.append(f"字幕解析失败：{e}")
    elif a.demo:
        # 演示：造一段含故意不合格的中文 SRT
        demo_srt = "\n\n".join([
            "1\n00:00:00,000 --> 00:00:02,000\n这是一句正常长度的字幕",
            "2\n00:00:02,000 --> 00:00:03,000\n"
            "这一行故意写得很长很长很长很长以满足超标判定条件",
            "3\n00:00:03,000 --> 00:00:05,500\n短句",
            "4\n00:00:05,000 --> 00:00:07,000\n与前一条时间轴重叠",
        ]) + "\n"
        cues = parse_srt(demo_srt)
        sub = check_subtitle(cues, a.lang)
        print("[INFO] 演示用内置 SRT（含 1 条 CPL 超标 + 1 条重叠）")
    else:
        warnings.append("未提供字幕文件，[C] 跳过")

    if sub:
        lim = sub["limits"]
        print(f" 语言 {a.lang}：CPS ≤ {lim['cps']}，CPL ≤ {lim['cpl']}，LPB ≤ {lim['lpb']}")
        print(f" 字幕条数：{sub['n_cues']}")
        print(f" 实测峰值：CPS {sub['cps_max']:.2f} | "
              f"CPL {sub['cpl_max']:.0f} | LPB {sub['lpb_max']:.0f}")
        print(f" 超标条数：CPS {sub['n_bad_cps']} | "
              f"CPL {sub['n_bad_cpl']} | LPB {sub['n_bad_lpb']}")
        print(f" 结构问题：重叠 {sub['n_overlap']} | "
              f"倒序 {sub['n_nonmono']} | 过短 {sub['n_tooshort']}")
        for it in sub["issues"]:
            problems.append(f"字幕：{it}")
        if not sub["issues"]:
            oks.append("字幕：全部合规")

    # ================= 汇总 =================
    hr("体检结论")
    if problems:
        print(f" ✗ 阻塞项 {len(problems)} 条（必须修，否则可能被直接筛掉）：")
        for p in problems:
            print(f"    · {p}")
    else:
        print(" ✓ 无阻塞项")
    if warnings:
        print(f"\n ! 未校验/提醒 {len(warnings)} 条：")
        for w in warnings:
            print(f"    · {w}")
    if oks:
        print(f"\n ✓ 通过 {len(oks)} 条：")
        for o in oks:
            print(f"    · {o}")

    verdict = "不予提交" if problems else ("可提交（有未校验项）" if warnings else "可提交")
    print(f"\n 判定：{verdict}")

    if a.export:
        Path(a.export).write_text(json.dumps(
            {"rule": a.rule, "problems": problems,
             "warnings": warnings, "ok": oks,
             "subtitle": sub, "verdict": verdict},
            ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[OK] 导出 {a.export}")

    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()
