#!/usr/bin/env bash
# TREC 官方 trec_eval 一键评测 (需要本机已编译 NIST 官方二进制)
#
# 编译 (一次即可):
#   git clone https://github.com/usnistgov/trec_eval.git && cd trec_eval && make
#   export PATH=$PATH:$(pwd)
#
# 用法:
#   ./eval_official.sh <qrels> <run> [rel_level] [max_docs] [runtag]
#   ./eval_official.sh ../data/2025-rag-qrels.txt myrun.txt 1 100 mySystem
set -euo pipefail

QRELS=${1:?缺少参数: qrels}
RUN=${2:?缺少参数: run}
REL=${3:-1}
MAXD=${4:-1000}
TAG=${5:-$(basename "$RUN" .txt)}

command -v trec_eval >/dev/null 2>&1 || {
  echo "[错误] 未找到 trec_eval。请先编译: git clone https://github.com/usnistgov/trec_eval.git && cd trec_eval && make" >&2
  exit 127
}

echo "=============================================================="
echo " TREC 官方评测 | run=$TAG | -l $REL | -M $MAXD"
echo "=============================================================="

# 主指标: nDCG@10 (分级相关性首选; 二值相关性时 ndcg_cut 与 MAP 趋势一致)
echo "--- 主指标 ---"
trec_eval -c -M "$MAXD" -m ndcg_cut.10,100 -l "$REL" "$QRELS" "$RUN"

# 召回与排序质量
echo "--- 召回 / MAP / MRR ---"
trec_eval -c -M "$MAXD" -m recall.100,1000 -m map -m recip_rank -l "$REL" "$QRELS" "$RUN"

# 判定覆盖率: 诊断非官方 run 是否大量命中未判定文档
echo "--- 诊断: Top-10 判定覆盖率 ---"
trec_eval -c -M "$MAXD" -m judged_cut.10 -m P.10 -l "$REL" "$QRELS" "$RUN" 2>/dev/null \
  || trec_eval -c -M "$MAXD" -m P.10 -l "$REL" "$QRELS" "$RUN"

echo
echo "口径说明:"
echo "  -c    : 在 qrels 全量主题上平均, run 缺失的主题计 0 (官方默认行为)"
echo "  -l $REL : 只有 rel >= $REL 的文档视为相关"
echo "  -M $MAXD: 每主题只取前 $MAXD 条"
echo "  judged_cut.10 偏低(<0.5)说明大量返回文档未被人工判定,"
echo "  绝对数值不可与官方 run 直接横向比较。"
