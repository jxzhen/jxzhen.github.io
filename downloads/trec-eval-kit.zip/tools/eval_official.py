#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TREC 官方指标计算 (无需官方 C 二进制的等价实现)

底层 = pytrec_eval-terrier, 它直接编译了 NIST trec_eval 的 C 源码,
数值与 `trec_eval` 命令行一致 (Anserini/Pyserini 官方回归测试即用它)。

本脚本补齐官方命令行常用的两个开关:
  -l N   相关性阈值: rel >= N 才算相关 (TREC DL 官方口径 N=2)
  -M D   截断深度  : 每主题只取前 D 条 (对应 `trec_eval -M 100`)

用法:
  python3 eval_official.py --qrels ../data/2025-rag-qrels.txt --run myrun.txt
  python3 eval_official.py --qrels qrels.txt --run run.txt -l 2 -M 100
  python3 eval_official.py --qrels qrels.txt --run run.txt --per-topic
  python3 eval_official.py --qrels qrels.txt --run run.txt --measure-set dl   # DL 官方口径指标组
"""
import argparse
import statistics
import sys

import pytrec_eval

# 指标名按 "官方 trec_eval 写法" 给出, 内部自动映射为 pytrec_eval 的 key
DL_MEASURES = "ndcg_cut.10,map_cut.100,map,recip_rank,recall.100,recall.1000,P.10"
RAG_MEASURES = "ndcg_cut.10,ndcg_cut.100,map_cut.100,recip_rank,recall.100,recall.1000,P.10"
DEFAULT_MEASURES = RAG_MEASURES

MEASURE_SETS = {"dl": DL_MEASURES, "rag": RAG_MEASURES, "default": DEFAULT_MEASURES}


def parse_measures(spec):
    """'ndcg_cut.10' -> (请求名 'ndcg_cut', 结果键 'ndcg_cut_10')"""
    req, keys = set(), []
    for s in [x.strip() for x in spec.split(",") if x.strip()]:
        base, _, cut = s.partition(".")
        req.add(base)
        keys.append(base if not cut else "%s_%s" % (base, cut))
    return req, keys


def read_qrels(path):
    out = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            p = line.split()
            if len(p) != 4:
                continue
            out.setdefault(p[0], {})[p[2]] = int(p[3])
    return out


def read_run(path, max_docs):
    """按 score 降序重排后截断, 等价于 trec_eval -M"""
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            p = line.split()
            if len(p) != 6:
                continue
            rows.append((p[0], p[2], float(p[4]), int(p[3])))
    by_q = {}
    for qid, docid, score, rank in rows:
        by_q.setdefault(qid, []).append((score, rank, docid))
    out = {}
    for qid, items in by_q.items():
        items.sort(key=lambda x: (-x[0], x[1]))
        out[qid] = {d: s for s, _, d in items[:max_docs]}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--qrels", required=True)
    ap.add_argument("--run", required=True)
    ap.add_argument("-l", "--rel-level", type=int, default=1,
                    help="相关性阈值 rel>=N 才算相关; TREC DL 官方口径=2; RAG 2025 分级 0-4, 常用 1 或 2")
    ap.add_argument("-M", "--max-docs", type=int, default=1000,
                    help="每主题截断深度, 默认 1000; TREC 2025 RAG 提交为 100")
    ap.add_argument("--measure-set", choices=list(MEASURE_SETS), default="default")
    ap.add_argument("--measures", default=None, help="自定义指标, 覆盖 --measure-set, 用官方写法逗号分隔")
    ap.add_argument("--per-topic", action="store_true")
    args = ap.parse_args()

    spec = args.measures or MEASURE_SETS[args.measure_set]
    req, keys = parse_measures(spec)

    supported = pytrec_eval.supported_measures
    use = sorted(req & supported)
    dropped = sorted(req - supported)
    if dropped:
        print("[提示] 不支持、已跳过的指标: %s" % dropped)
    if not use:
        print("无可用指标。支持的基名: %s" % sorted(supported))
        return 1

    qrel = read_qrels(args.qrels)
    run = read_run(args.run, args.max_docs)

    # relevance_level 即 trec_eval 的 -l
    evaluator = pytrec_eval.RelevanceEvaluator(qrel, set(use), relevance_level=args.rel_level)
    res = evaluator.evaluate(run)

    all_topics = sorted(qrel.keys())  # 官方口径: 对全部主题平均, 缺失计 0
    print("=" * 74)
    print("TREC 官方指标 | qrels=%s | run=%s | -l %d | -M %d" %
          (args.qrels, args.run, args.rel_level, args.max_docs))
    print("=" * 74)
    print("qrels 主题数=%d   run 覆盖主题数=%d" % (len(all_topics), len(res)))
    missing = [t for t in all_topics if t not in res]
    if missing:
        print("[WARN] run 未覆盖 %d 个主题, 按 0 计入平均: %s" % (len(missing), missing[:10]))

    print("\n%-16s %10s %10s %10s" % ("指标", "均值", "中位", "标准差"))
    print("-" * 74)
    agg = {}
    for k in keys:
        vals = [res.get(t, {}).get(k, 0.0) for t in all_topics]
        if not vals:
            continue
        mean = statistics.mean(vals)
        agg[k] = mean
        print("%-16s %10.4f %10.4f %10.4f" %
              (k, mean, statistics.median(vals), statistics.pstdev(vals) if len(vals) > 1 else 0.0))
    print("-" * 74)
    main_key = "ndcg_cut_10"
    if main_key in agg:
        print("主指标 nDCG@10 = %.4f" % agg[main_key])

    if args.per_topic:
        print("\n逐主题 nDCG@10:")
        for t in all_topics:
            print("  %-8s %.4f" % (t, res.get(t, {}).get(main_key, 0.0)))

    print("\n" + ("-" * 74))
    print("若本机已编译 NIST 官方 trec_eval (github.com/usnistgov/trec_eval), 等价命令:")
    print("  trec_eval -c -m ndcg_cut.10            -l %d %s %s"
          % (args.rel_level, args.qrels, args.run))
    print("  trec_eval -c -M %d -m map -m recip_rank -l %d %s %s"
          % (args.max_docs, args.rel_level, args.qrels, args.run))
    print("  trec_eval -c -m recall.100,1000        -l %d %s %s"
          % (args.rel_level, args.qrels, args.run))
    print("注: -c 强制在 qrels 全量主题上平均(缺失主题计 0); -M 截断深度; -l 相关性阈值。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
