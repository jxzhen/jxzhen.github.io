#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TREC 官方评测 提交前格式校验器
适用: TREC 2025 RAG (retrieval 子任务) / TREC Deep Learning 2021-2023 / 通用 TREC ad-hoc

检查项:
  A. qrels 格式    : 4 列、相关性等级为整数、(qid, docid) 不重复
  B. run 格式      : 6 列、Q0 占位、rank 连续自 1 起、score 非升序、docid 不重复、runtag 唯一
  C. 主题集对齐    : run 是否覆盖 qrels 全部主题 / 是否混入无关主题
  D. 文档粒度对齐  : segment(docid#seg) 与 整篇(docid) 是否混用 —— 这是 TREC 2025 RAG 最致命的坑
  E. 深度合规      : 每主题返回条数是否超过赛道上限

用法:
  python3 check_format.py --qrels ../data/2025-rag-qrels.txt --run myrun.txt
  python3 check_format.py --qrels qrels.txt --run run.txt --max-hits 100 --strict
退出码: 0=通过  1=存在错误(必须修)  2=仅警告
"""
import argparse
import collections
import sys

OK, WARN, ERR = "  [OK]  ", "  [WARN]", "  [ERR] "


def load_qrels(path):
    rows, bad = [], []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            s = line.rstrip("\n")
            if not s.strip():
                continue
            p = s.split()
            if len(p) != 4:
                bad.append((i, s, "列数 != 4"))
                continue
            qid, it, docid, rel = p
            try:
                rel_i = int(rel)
            except ValueError:
                bad.append((i, s, "相关性等级非整数"))
                continue
            rows.append((qid, it, docid, rel_i))
    return rows, bad


def load_run(path):
    rows, bad = [], []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            s = line.rstrip("\n")
            if not s.strip():
                continue
            p = s.split()
            if len(p) != 6:
                bad.append((i, s, "列数 != 6 (应为 qid Q0 docid rank score runtag)"))
                continue
            qid, q0, docid, rank, score, tag = p
            try:
                rank_i = int(rank)
                score_f = float(score)
            except ValueError:
                bad.append((i, s, "rank/score 非数值"))
                continue
            rows.append((qid, q0, docid, rank_i, score_f, tag))
    return rows, bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--qrels", required=True)
    ap.add_argument("--run", required=True)
    ap.add_argument("--max-hits", type=int, default=100,
                    help="每主题最大返回条数上限, TREC 2025 RAG retrieval = 100, 通用 ad-hoc = 1000")
    ap.add_argument("--strict", action="store_true", help="警告也视为失败")
    args = ap.parse_args()

    n_err = n_warn = 0

    def e(msg):
        nonlocal n_err
        n_err += 1
        print(ERR + msg)

    def w(msg):
        nonlocal n_warn
        n_warn += 1
        print(WARN + msg)

    def ok(msg):
        print(OK + msg)

    print("=" * 68)
    print("TREC 提交格式校验  |  qrels=%s  run=%s" % (args.qrels, args.run))
    print("=" * 68)

    # ---------- A. qrels ----------
    qrows, qbad = load_qrels(args.qrels)
    print("\n[A] qrels 解析")
    for i, s, why in qbad[:5]:
        e("第 %d 行异常(%s): %s" % (i, why, s))
    if len(qbad) > 5:
        e("... 另有 %d 行异常" % (len(qbad) - 5))

    q_by_topic = collections.defaultdict(list)
    dup_qrel = 0
    seen = set()
    for qid, _, docid, rel in qrows:
        q_by_topic[qid].append((docid, rel))
        k = (qid, docid)
        if k in seen:
            dup_qrel += 1
        seen.add(k)
    if dup_qrel:
        e("qrels 存在 %d 条重复 (qid, docid)" % dup_qrel)
    else:
        ok("qrels 无重复判定")
    grades = sorted({r for _, _, _, r in qrows})
    print("       主题数=%d  判定条数=%d  相关性等级=%s" % (len(q_by_topic), len(qrows), grades))
    npos = sum(1 for t in q_by_topic.values() for _, r in t if r > 0)
    if npos == 0:
        e("qrels 中没有任何 rel>0 的文档, 评测结果必然全 0")
    topics_no_pos = [q for q, v in q_by_topic.items() if not any(r > 0 for _, r in v)]
    if topics_no_pos:
        w("有 %d 个主题无正例(评测时将被计 0): %s" % (len(topics_no_pos), topics_no_pos[:8]))

    # ---------- B. run ----------
    rrows, rbad = load_run(args.run)
    print("\n[B] run 解析")
    for i, s, why in rbad[:5]:
        e("第 %d 行异常(%s): %s" % (i, why, s))
    if len(rbad) > 5:
        e("... 另有 %d 行异常" % (len(rbad) - 5))

    r_by_topic = collections.defaultdict(list)
    tags = set()
    bad_q0 = 0
    for qid, q0, docid, rank, score, tag in rrows:
        r_by_topic[qid].append((rank, score, docid))
        tags.add(tag)
        if q0 != "Q0":
            bad_q0 += 1
    if bad_q0:
        e("有 %d 行第 2 列不是 Q0" % bad_q0)
    else:
        ok("第 2 列均为 Q0 占位")
    if len(tags) > 1:
        e("run 中出现多个 runtag: %s (官方要求单一 runtag)" % sorted(tags)[:5])
    else:
        ok("runtag 唯一: %s" % (sorted(tags)[0] if tags else "-"))

    # rank 连续性与 score 单调性
    rank_bad = score_bad = dup_doc = 0
    depth_over = []
    depth_zero = []
    for qid, items in r_by_topic.items():
        if len({d for _, _, d in items}) != len(items):
            dup_doc += 1
        items_sorted = sorted(items, key=lambda x: x[0])
        if [x[0] for x in items_sorted] != list(range(1, len(items_sorted) + 1)):
            rank_bad += 1
        sc = [x[1] for x in items_sorted]
        if any(sc[i] < sc[i + 1] for i in range(len(sc) - 1)):
            score_bad += 1
        if len(items) > args.max_hits:
            depth_over.append((qid, len(items)))
        if len(items) == 0:
            depth_zero.append(qid)
    if rank_bad:
        e("有 %d 个主题 rank 不自 1 连续递增" % rank_bad)
    else:
        ok("rank 均自 1 连续")
    if score_bad:
        e("有 %d 个主题 score 非降序 (官方按 score 排序, 乱序会导致指标虚低)" % score_bad)
    else:
        ok("score 均为降序")
    if dup_doc:
        e("有 %d 个主题存在重复 docid" % dup_doc)
    else:
        ok("同一主题内 docid 无重复")
    if depth_over:
        e("有 %d 个主题超过 %d 条: 例如 %s" % (len(depth_over), args.max_hits, depth_over[:5]))
    else:
        ok("每主题返回条数 <= %d" % args.max_hits)
    print("       run 主题数=%d  总行数=%d  平均深度=%.1f" %
          (len(r_by_topic), len(rrows), len(rrows) / max(1, len(r_by_topic))))

    # ---------- C. 主题集对齐 ----------
    print("\n[C] 主题集对齐")
    qt, rt = set(q_by_topic), set(r_by_topic)
    missing = qt - rt
    extra = rt - qt
    if missing:
        e("run 缺少 %d 个主题(官方按全量主题平均, 缺失计 0): %s" % (len(missing), sorted(missing)[:10]))
    else:
        ok("run 覆盖 qrels 全部 %d 个主题" % len(qt))
    if extra:
        w("run 含 %d 个 qrels 中不存在的主题(将被忽略): %s" % (len(extra), sorted(extra)[:10]))
    if depth_zero:
        w("有 %d 个主题返回 0 条结果" % len(depth_zero))

    # ---------- D. 文档粒度对齐 (TREC 2025 RAG 关键坑) ----------
    print("\n[D] 文档粒度对齐 (segment 级 vs 文档级)")
    q_seg = sum(1 for _, _, d, _ in qrows if "#" in d)
    r_docs = [d for items in r_by_topic.values() for _, _, d in items]
    r_seg = sum(1 for d in r_docs if "#" in d)
    q_ratio, r_ratio = q_seg / max(1, len(qrows)), r_seg / max(1, len(r_docs))
    print("       qrels 中含 '#' (segment级) 比例: %.1f%%" % (q_ratio * 100))
    print("       run   中含 '#' (segment级) 比例: %.1f%%" % (r_ratio * 100))
    if q_ratio > 0.9 and r_ratio < 0.1:
        e("粒度不匹配: qrels 是 segment 级(docid#seg), 你的 run 是文档级。"
          " 所有文档都会被判为 unjudged, 指标恒为 0 —— 必须改用 segmented 语料检索。")
    elif q_ratio < 0.1 and r_ratio > 0.9:
        e("粒度不匹配: qrels 是文档级, 你的 run 是 segment 级。指标会严重偏低。")
    else:
        ok("文档粒度一致 (%s)" % ("segment 级" if q_ratio > 0.5 else "文档级"))

    # 未判定率
    judged = {(q, d) for q, _, d, _ in qrows}
    run_pairs = {(q, d) for q, items in r_by_topic.items() for _, _, d in items}
    unjudged = run_pairs - judged
    print("       run 中未出现在 qrels 的 (主题,文档) 对: %d / %d (%.1f%%)" %
          (len(unjudged), len(run_pairs), 100.0 * len(unjudged) / max(1, len(run_pairs))))
    if len(run_pairs) and len(unjudged) / len(run_pairs) > 0.5:
        w("超过一半的返回文档未被判定。TREC 用 pooling 构建 qrels, "
          "非官方 run 的高未判定率是正常的, 但会导致你的绝对数值不可与官方 run 横向比较。")

    # ---------- 汇总 ----------
    print("\n" + "=" * 68)
    print("结果: %d 个错误, %d 个警告" % (n_err, n_warn))
    if n_err:
        print("结论: 不通过, 必须先修复错误项。")
        return 1
    if n_warn and args.strict:
        print("结论: strict 模式下警告视为失败。")
        return 1
    print("结论: 通过。可提交 / 可评测。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
