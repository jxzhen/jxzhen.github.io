#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
用 qrels 反造演示 run, 用于自检评测工具链是否正确安装/口径是否对齐。
三种模式:
  oracle   完美排序(按相关性等级降序)        -> nDCG@10 应接近 1.0
  shuffle  随机打乱                          -> nDCG@10 明显下降
  doclevel 故意去掉 '#段号' 退化成文档级     -> 应触发校验器 [ERR] 且指标恒为 0

用法:
  python3 make_demo_run.py --qrels ../data/2025-rag-qrels.txt --mode oracle  --out run.oracle.txt
"""
import argparse
import random
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--qrels", required=True)
    ap.add_argument("--mode", choices=["oracle", "shuffle", "doclevel"], default="oracle")
    ap.add_argument("--out", required=True)
    ap.add_argument("--depth", type=int, default=100, help="每主题返回条数")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--tag", default="demo")
    args = ap.parse_args()

    random.seed(args.seed)
    by_q = {}
    with open(args.qrels, encoding="utf-8") as f:
        for line in f:
            p = line.split()
            if len(p) != 4:
                continue
            by_q.setdefault(p[0], []).append((p[2], int(p[3])))

    with open(args.out, "w", encoding="utf-8") as out:
        for qid in sorted(by_q, key=lambda x: int(x) if x.isdigit() else x):
            items = list(by_q[qid])
            if args.mode == "oracle":
                items.sort(key=lambda x: -x[1])
            elif args.mode == "shuffle":
                random.shuffle(items)
            score = 1.0
            for rank, (docid, rel) in enumerate(items[:args.depth], 1):
                d = docid.split("#")[0] if args.mode == "doclevel" else docid
                out.write("%s Q0 %s %d %.6f %s\n" % (qid, d, rank, score, args.tag))
                score -= 0.001
    print("已生成 %s (mode=%s, 主题数=%d, 深度=%d)" %
          (args.out, args.mode, len(by_q), args.depth))
    return 0


if __name__ == "__main__":
    sys.exit(main())
