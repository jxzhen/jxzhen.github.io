# TREC 官方评测跑通清单（RAG 2025 / Deep Learning 2021–2023）

面向**官方评测竞赛**（TREC，NIST 主办）的数据集 + 评价工具落地手册。
套件内已包含**真实官方 qrels**（TREC 2025 RAG，NIST 直下）和三个已跑通验证的脚本。

> 语料（MS MARCO V2.1，约 28 GB）不在本套件内，需自行下载，见 §2。

---

## 1. 套件能做什么

| 能力 | 说明 |
|---|---|
| 指标计算 | 等价于 NIST `trec_eval` 官方数值（底层编译的是同一份 C 源码） |
| 提交前格式校验 | 覆盖 TREC run/qrels 全部硬性格式约束 + 两个致命语义坑 |
| 工具链自检 | 用 oracle/shuffle 两种反造 run 验证你的评测口径没配错 |
| 官方命令对照 | 自动打印等价的 `trec_eval` 命令行，便于论文/报告复现 |

**已在本沙箱用真实官方数据验证的结果：**

| 演示 run | nDCG@10 | 说明 |
|---|---|---|
| `run.oracle.txt`（完美排序） | **1.0000** | 工具链与口径正确时必得 1.0 |
| `run.shuffle.txt`（随机排序） | **0.4034** | 正常退化 |
| `run.doclevel.txt`（文档级 vs segment 级错配） | **0.0000** | 实证了 §6 的第 1 号坑 |

---

## 2. 官方数据集清单

### 2.1 TREC 2025 RAG Track（第 34 届 TREC，2025-12 召开）

**语料**（沿用 2024，官方公告页给直链，需同意 MS MARCO 使用协议）：

| 集合 | 文件 | 记录数 | 体积 | MD5 |
|---|---|---|---|---|
| MS MARCO V2.1 文档集 | `msmarco_v2.1_doc.tar` | 10,960,555 | 28.1 GB | `a5950665d6448d3dbaf7135645f1e074` |
| 同上（分段版） | `msmarco_v2.1_doc_segmented.tar` | 113,520,750 | 25.1 GB | `3799e7611efffd8daeb257e9ccca4d60` |

- 格式：70 个 gzip JSONL 打包进 tar；字段 `docid / url / title / headings / body`
- 分段版 docid 形如 `msmarco_v2.1_doc_29_677149#8_3138708572`，**`#` 前是文档、后是段落**；分段方式为 10 句滑动窗口、stride 5，段长 500–1000 字符
- 文档 docid 编码了文件名与字节偏移，便于随机读取

**Topics / Qrels（NIST 官方直链，本套件已下载）**：

| 类型 | 地址 | 形态 |
|---|---|---|
| Topics（叙述型查询） | `https://trec.nist.gov/data/rag/trec25_narratives_final.json` | JSON：`id` + `narrative` |
| Topics（含子叙述） | `https://trec.nist.gov/data/rag/trec25_narratives_final_w_questions_w_sub_narratives_edit_20250822.json` | JSON |
| Qrels（文档相关性） | `https://trec.nist.gov/data/rag/2025-rag-qrels.txt` | TREC qrels，分级 **0–4** |
| Qrels（nugget 级） | `https://github.com/castorini/trec25-rag` | 官方 nuggetizer |

> 2025 赛季相对 2024 的关键变化：**查询从短关键词改为多句叙述型（narrative）**，并按"文档回答了多少个子叙述"打 0–4 分；评测为四层：相关性判定 → nugget 覆盖度 → 引用归因校验 → 一致性分析（Cohen's κ）。
> 本套件下载到的 `2025-rag-qrels.txt` 含 **22 个主题 / 10,284 条判定**，等级分布 `{0:3619, 1:1499, 2:3760, 3:1318, 4:88}`。官方可能分批发布，**正式使用时请以官方发布页与 overview 论文的口径为准并核对 MD5**。

### 2.2 TREC Deep Learning Track（2021–2023，已收官，仍是稠密检索最常用官方测试集）

| 用途 | 文件 | 记录数 | MD5 |
|---|---|---|---|
| DL21 qrels | `qrels.dl21-doc-msmarco-v2.1.txt` | 10,973 | `6845b6c128aec71027e72078a960600e` |
| DL22 qrels | `qrels.dl22-doc-msmarco-v2.1.txt` | 349,541 | `ac9f5c6fcb6972d8bf13b07ab150680a` |
| DL23 qrels | `qrels.dl23-doc-msmarco-v2.1.txt` | 15,995 | `4b30e8850b6fba56289b6c177afe959b` |
| Dev / Dev2 qrels | `qrels.msmarco-v2.1-doc.dev.txt` / `.dev2.txt` | 4,702 / 5,177 | `089b19dce...` / `8ff337f21...` |
| DL21/22/23 topics | `topics.dl21.txt` / `dl22.txt` / `dl23.txt` | 477 / 500 / 700 | `46d863434...` / `f1bfd53d8...` / `7df9e17b4...` |
| Dev / Dev2 topics | `topics.msmarco-v2-doc.dev.txt` / `.dev2.txt` | 4,552 / 5,000 | `b05dc19f1...` / `f000319f1...` |

下载（Anserini 官方维护副本）：

```bash
BASE=https://raw.githubusercontent.com/castorini/anserini/master/tools/topics-and-qrels
for f in qrels.dl21-doc-msmarco-v2.1.txt qrels.dl23-doc-msmarco-v2.1.txt \
         topics.dl21.txt topics.dl23.txt; do
  curl -sSL -o "$f" "$BASE/$f"
done
# 校验
md5sum qrels.dl23-doc-msmarco-v2.1.txt   # 应得 4b30e8850b6fba56289b6c177afe959b
```

> DL23 的 700 个查询 = 200 条人工真实查询 + 250 条 T5 合成 + 250 条 GPT-4 合成，官方刻意提高难度。
> GitHub 若不通，改用 Pyserini 自动获取：`python -m pyserini.search.lucene --topics dl23 ...`（Pyserini 内置这些 topic/qrels 的下载逻辑）。

---

## 3. 评价工具：两条路

### 路线 A（推荐，本套件默认）：`pytrec_eval-terrier`

```bash
pip3 install pytrec_eval-terrier
```

它直接编译了 NIST `trec_eval` 的 C 源码，Anserini / Pyserini 的官方回归测试即用它，**数值与命令行一致**。已验证版本 `0.5.10`。

### 路线 B：NIST 官方 `trec_eval` 二进制

```bash
git clone https://github.com/usnistgov/trec_eval.git
cd trec_eval && make          # 需要 gcc
export PATH=$PATH:$(pwd)
trec_eval --help              # 列出全部指标
```

需要多样性/意图感知指标时再编译官方 `ndeval`（α-nDCG、ERR-IA、NRBP）：`https://github.com/usnistgov/ndeval`。

---

## 4. 完整跑通流程

```bash
cd /workspace/trec-eval-kit

# 步骤 0 · 取官方数据（已含在 data/，可重下）
curl -sSL -o data/2025-rag-qrels.txt https://trec.nist.gov/data/rag/2025-rag-qrels.txt
curl -sSL -o data/trec25_narratives_final.json https://trec.nist.gov/data/rag/trec25_narratives_final.json

# 步骤 1 · 自检工具链（用 qrels 反造的完美 run，nDCG@10 必须为 1.0000）
python3 tools/make_demo_run.py --qrels data/2025-rag-qrels.txt --mode oracle  --out data/run.oracle.txt
python3 tools/eval_official.py --qrels data/2025-rag-qrels.txt --run data/run.oracle.txt -l 1 -M 100

# 步骤 2 · 把你的系统输出转成 TREC run 格式（见 §5），例如 myrun.txt

# 步骤 3 · 提交前格式校验（有 [ERR] 必须先修）
python3 tools/check_format.py --qrels data/2025-rag-qrels.txt --run myrun.txt --max-hits 100

# 步骤 4 · 算官方指标
python3 tools/eval_official.py --qrels data/2025-rag-qrels.txt --run myrun.txt -l 1 -M 100

# 步骤 4' · 若已编译官方 trec_eval，改用 shell 版
bash tools/eval_official.sh data/2025-rag-qrels.txt myrun.txt 1 100 mySystem
```

---

## 5. TREC 标准数据格式（四件套）

**run 文件**（每行 6 列，空白分隔）：

```
14 Q0 msmarco_v2.1_doc_26_1828280420#8_3138708572 1 12.483001 mySystem
14 Q0 msmarco_v2.1_doc_03_1195900215#2_1993207047 2 12.102334 mySystem
```

| 列 | 含义 | 硬约束 |
|---|---|---|
| 1 | topic id | 必须与 qrels 中的 qid 完全一致（注意前导零/类型） |
| 2 | 占位 | 固定 `Q0` |
| 3 | docid | **粒度必须与 qrels 一致**（见 §6 坑 1） |
| 4 | rank | 从 1 开始连续递增 |
| 5 | score | 浮点，降序；越大越相关 |
| 6 | runtag | 全文件唯一，官方用它标识一次提交 |

**qrels 文件**（每行 4 列）：`topic_id  0  doc_id  relevance`，第 2 列 `0` 是历史遗留占位列。

**深度限制**：TREC 2025 RAG retrieval 子任务提交 **Top-100**；通用 ad-hoc / DL 通常 1000。

---

## 6. 常见坑（按杀伤力排序）

| # | 坑 | 表现 | 规避 |
|---|---|---|---|
| 1 | **文档粒度错配**：qrels 用 segment 级 `docid#seg`，你检索用的是整篇 `docid` | 全部文档判为 unjudged，**指标恒为 0** | 必须用 `msmarco_v2.1_doc_segmented` 建索引；`check_format.py` 的 [D] 项专门查这个 |
| 2 | **未判定率过高**：TREC qrels 由 pooling 构建，只判过参赛系统 Top-k 汇总的文档 | 自造 run 大量命中未判定文档，绝对数值**不可与官方 run 横向比较** | 看 `judged_cut.10`；论文里如实说明"非官方 run，仅作系统间相对比较" |
| 3 | **相关性阈值 `-l` 用错** | DL 分级 0–3 官方按 `rel>=2` 算相关；RAG 2025 是 0–4 | 对照当届 overview 论文；本脚本 `-l` 显式可调，写论文时注明 |
| 4 | **缺主题** | run 少了某几个 topic | 官方按 qrels 全量主题平均，缺失计 0；用 `-c` 并让 `check_format.py` 查 [C] 项 |
| 5 | **乱序 / 重复 docid / 多 runtag** | 指标虚低或官方直接拒收 | `check_format.py` 的 [B] 项全查 |
| 6 | 拿 BEIR / MTEB 当"官方评测"表述 | 审稿人质疑 | BEIR/MTEB 是研究者整理的 benchmark 与排行榜，**不是官方评测竞赛**，写法上要区分 |

---

## 7. 指标口径速查

| 指标 | `trec_eval` 写法 | 何时用 |
|---|---|---|
| nDCG@10 | `-m ndcg_cut.10` | **主指标**，兼容二值与分级 qrels |
| MAP@100 | `-M 100 -m map` | 强调召回完整度（DL 官方并列主指标） |
| MRR | `-m recip_rank` | 已知项检索 / 单答案场景 |
| Recall@k | `-m recall.100,1000` | 重排前召回池质量；R@1000 低说明候选就没捞到，rerank 救不回来 |
| P@10 | `-m P.10` | 首屏精确度 |
| judged_cut.10 | `-m judged_cut.10` | 诊断用：Top-10 有多少被人工判定过 |
| α-nDCG / ERR-IA / NRBP | `ndeval` | 多样性、多意图查询 |

关键开关：`-c` 在 qrels 全量主题上平均（缺失计 0）；`-l N` 相关性阈值；`-M D` 截断深度。

---

## 8. 基线参考（用于判断你的系统是否正常）

**TREC DL 2023 passage（Anserini 官方回归）**：

| 系统 | nDCG@10 | MAP@100 | MRR@100 | R@100 | R@1000 |
|---|---|---|---|---|---|
| BM25 | 0.2061 | 0.0751 | 0.3696 | 0.2365 | 0.4514 |
| SPLADE++ CoCondenser-SelfDistil | 0.4768 | 0.1963 | 0.6985 | 0.4137 | 0.6731 |
| SPLADE++ + Rocchio | 0.4774 | 0.2065 | 0.7100 | 0.4226 | 0.7056 |

**MS MARCO V2 doc dev（Pyserini BM25 基线）**：文档级 map 0.1552 / MRR 0.1572 / R@100 0.5956 / R@1000 0.8054；分段级 map 0.1875 / MRR 0.1896 / R@100 0.6555 / R@1000 0.8542。

跑出来的数远低于 BM25 基线，先怀疑 §6 的坑 1 和坑 3，而不是模型问题。

---

## 9. 文件清单

```
trec-eval-kit/
├── README.md                    本文档
├── data/
│   ├── 2025-rag-qrels.txt       官方 TREC 2025 RAG qrels（22 主题 / 10284 条）
│   ├── trec25_narratives_final.json   官方叙述型 topics
│   ├── run.oracle.txt           自检用：完美排序（nDCG@10=1.0）
│   ├── run.shuffle.txt          自检用：随机排序（nDCG@10=0.4034）
│   └── run.doclevel.txt         反例：粒度错配（nDCG@10=0.0）
└── tools/
    ├── check_format.py          提交前格式校验（退出码 0/1）
    ├── eval_official.py         官方指标计算（Python 路线）
    ├── eval_official.sh         官方指标计算（trec_eval 二进制路线）
    └── make_demo_run.py         反造演示 run，自检工具链
```
