#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
字幕赛道评测（对应研究内容5：英文视频 → 中文字幕自动生成）。

为什么字幕不能用 BLEU 单独评价
------------------------------
字幕不只是"译文"，它还必须满足播出约束：
  * 分段（一行多长、一个块几行）
  * 时间轴（与画面对得上、可读速度合理）
BLEU 只看文本，**完全看不见分段与时间轴**。
IWSLT 2022 提出 SubER（Wilken, Georgakopoulou, Matusov, AppTek），
用"带 shift 的编辑距离"把文本编辑代价与分段/时间偏移代价统一成一个数，
并已被 IWSLT 采纳为字幕赛道主指标。

本脚本做两件事
--------------
1. SubER  —— 直接调用官方实现（pip install subtitle-edit-rate），
             不做任何自造公式，保证与官方分数可复现。
2. CPS / CPL / LPB 合规率 —— IWSLT 2026 字幕赛道明文规定的三项播出约束：
     CPS  每秒字符数   中文上限 9 字/秒   （读不完）
     CPL  每行字符数   中文上限 16 字/行  （出画）
     LPB  每块行数     上限 2 行          （遮挡画面）
   合规脚本口径参照 Papi et al. 2023。

官方经验阈值（作者给出）：SubER < 20% 很好；> 40~50% 很差。

用法
----
  python3.12 subtitle_eval.py --hyp data/demo/hyp_cond.srt --ref data/demo/ref.srt --lang zh
  python3.12 subtitle_eval.py --hyp data/demo/hyp_raw.srt  --ref data/demo/ref.srt --lang zh
  python3.12 subtitle_eval.py --hyp h.srt --ref r.srt --lang zh --cased --all-metrics
"""

import argparse
import json
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from check_format import parse_srt, read_lines  # noqa: E402

# IWSLT 2026 字幕赛道官方约束（中文）；其他语言请改这里
LIMITS = {
    "zh": {"CPS": 9.0, "CPL": 16, "LPB": 2},
    "en": {"CPS": 21.0, "CPL": 42, "LPB": 2},
    "ja": {"CPS": 9.0, "CPL": 16, "LPB": 2},
    "ko": {"CPS": 9.0, "CPL": 16, "LPB": 2},
}
DEFAULT_LIMITS = {"CPS": 21.0, "CPL": 42, "LPB": 2}

TAG = re.compile(r"<[^>]+>|\{[^}]*\}|\\N|\\n", re.IGNORECASE)


def visible(text_lines):
    """去掉 SRT 里常见的格式化标签后再统计长度。"""
    return [TAG.sub("", l).strip() for l in text_lines]


def compliance(blocks, lang):
    lim = LIMITS.get(lang, DEFAULT_LIMITS)
    n = len(blocks)
    cps_ok = cpl_ok = lpb_ok = 0
    cps_vals, cpl_vals, lpb_vals = [], [], []
    for _, st, en, lines in blocks:
        ls = [x for x in visible(lines) if x]
        if not ls:
            continue
        dur = max(en - st, 1e-6)
        nchar = sum(len(x) for x in ls)
        cps, cpl, lpb = nchar / dur, max(len(x) for x in ls), len(ls)
        cps_vals.append(cps)
        cpl_vals.append(cpl)
        lpb_vals.append(lpb)
        cps_ok += (cps <= lim["CPS"])
        cpl_ok += (cpl <= lim["CPL"])
        lpb_ok += (lpb <= lim["LPB"])
    m = len(cps_vals)
    return {
        "limits": lim, "n_blocks": m,
        "CPS%": 100 * cps_ok / m if m else 0,
        "CPL%": 100 * cpl_ok / m if m else 0,
        "LPB%": 100 * lpb_ok / m if m else 0,
        "CPS_mean": sum(cps_vals) / m if m else 0,
        "CPL_mean": sum(cpl_vals) / m if m else 0,
        "LPB_mean": sum(lpb_vals) / m if m else 0,
        "CPS_max": max(cps_vals) if cps_vals else 0,
        "CPL_max": max(cpl_vals) if cpl_vals else 0,
        "LPB_max": max(lpb_vals) if lpb_vals else 0,
    }


def run_suber(hyp, ref, lang, cased, all_metrics):
    """调用官方 suber CLI。失败时明确降级并提示，绝不自己造公式冒充 SubER。"""
    metrics = ["SubER-cased"] if cased else ["SubER"]
    if all_metrics:
        metrics += ["WER", "BLEU", "TER", "chrF", "CER"]
    cmd = ["suber", "-H", hyp, "-R", ref, "-m"] + metrics
    if lang in ("zh", "ja", "ko"):
        cmd += ["-l", lang]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    except FileNotFoundError:
        return None, "未找到 suber 命令。请先 pip install --break-system-packages subtitle-edit-rate"
    except subprocess.TimeoutExpired:
        return None, "suber 执行超时"
    out = (p.stdout or "").strip()
    if p.returncode != 0 or not out:
        return None, f"suber 返回码 {p.returncode}；stderr: {(p.stderr or '')[:300]}"
    try:
        # suber 可能在 JSON 前后打印额外信息，取最后一个 {...} 块
        m = re.findall(r"\{[^{}]*\}", out, re.S)
        return json.loads(m[-1]), " ".join(cmd)
    except Exception as e:
        return None, f"无法解析 suber 输出 ({e})：{out[:300]}"


def main():
    ap = argparse.ArgumentParser(description="字幕赛道评测：SubER + CPS/CPL/LPB 合规率")
    ap.add_argument("--hyp", required=True, help="系统输出字幕 SRT")
    ap.add_argument("--ref", required=True, help="参考字幕 SRT")
    ap.add_argument("--lang", default="zh", choices=["zh", "en", "ja", "ko"])
    ap.add_argument("--cased", action="store_true",
                    help="用 SubER-cased（含标点、区分大小写）；IWSLT 2026 主指标口径")
    ap.add_argument("--all-metrics", action="store_true",
                    help="同时输出 WER/BLEU/TER/chrF/CER")
    ap.add_argument("--json", help="把结果导出为 JSON")
    a = ap.parse_args()

    print("=" * 78)
    print(" 字幕赛道评测   SubER（官方实现） + 播出合规率")
    print("=" * 78)

    hb = parse_srt(a.hyp)
    rb = parse_srt(a.ref)
    print(f" 假设 {os.path.basename(a.hyp)}：{len(hb)} 块")
    print(f" 参考 {os.path.basename(a.ref)}：{len(rb)} 块")
    print(f" 语言 {a.lang}   指标 SubER{'-cased' if a.cased else ''}")

    # ---------- SubER ----------
    scores, info = run_suber(a.hyp, a.ref, a.lang, a.cased, a.all_metrics)
    print("\n---- SubER ----")
    if scores is None:
        print(f"  [降级] {info}")
        print("  未获得官方 SubER。请不要用自造编辑距离冒称 SubER 报数。")
    else:
        print(f"  $ {info}")
        for k, v in scores.items():
            if isinstance(v, (int, float)):
                arrow = "↓" if k.lower().startswith(("suber", "wer", "ter", "cer")) else "↑"
                print(f"  {k:12s}: {v:8.3f}  {arrow}")
        sub = scores.get("SubER", scores.get("SubER-cased"))
        if sub is not None:
            if sub < 20:
                verdict = "很好（< 20%）"
            elif sub < 40:
                verdict = "中等（20~40%）"
            else:
                verdict = "差（> 40%）"
            print(f"  判读：{verdict}   [官方经验阈值：<20 很好；>40~50 很差]")

    # ---------- 合规率 ----------
    comp = compliance(hb, a.lang)
    lim = comp["limits"]
    print("\n---- 播出合规率（越高越好）----")
    print(f"  约束上限：CPS <= {lim['CPS']} 字/秒   CPL <= {lim['CPL']} 字/行   LPB <= {lim['LPB']} 行/块")
    print(f"  {'指标':<8}{'合规率':>10}{'实测均值':>12}{'最坏值':>10}")
    print(f"  {'CPS':<8}{comp['CPS%']:>9.2f}%{comp['CPS_mean']:>12.2f}{comp['CPS_max']:>10.2f}")
    print(f"  {'CPL':<8}{comp['CPL%']:>9.2f}%{comp['CPL_mean']:>12.2f}{comp['CPL_max']:>10.0f}")
    print(f"  {'LPB':<8}{comp['LPB%']:>9.2f}%{comp['LPB_mean']:>12.2f}{comp['LPB_max']:>10.0f}")
    worst = min(comp["CPS%"], comp["CPL%"], comp["LPB%"])
    if worst < 80:
        print(f"\n  !! 最低合规率 {worst:.2f}% —— 该字幕基本不可直接播出，"
              f"需要引入压缩/重分段（condensation）后处理。")
    else:
        print(f"\n  最低合规率 {worst:.2f}%，达到可播出水平。")

    if a.json:
        with open(a.json, "w", encoding="utf-8") as f:
            json.dump({"suber": scores, "compliance": comp}, f, ensure_ascii=False, indent=2)
        print(f"\n[OK] 结果导出 -> {a.json}")


if __name__ == "__main__":
    main()
