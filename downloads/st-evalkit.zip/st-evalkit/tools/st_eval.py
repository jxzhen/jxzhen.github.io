#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
离线语音翻译质量评测（对齐 IWSLT / WMT 官方口径）。

指标说明
--------
* BLEU    —— IWSLT 历届**主指标**，大小写敏感（case-sensitive）。
             官方要求先用 mwerSegmenter / mweralign 对假设做重分段，
             再计算 BLEU；否则分段不一致会严重低估（见 check_format.py [A]）。
* chrF   —— 字符 n-gram F 值，对形态丰富语言与中文更稳健。
* TER    —— 翻译编辑率，越低越好。
* WER/CER —— **不是翻译指标**，是 ASR 指标。放在这里是做归因诊断：
             级联系统 = ASR + MT，若 WER 高而 BLEU 低，瓶颈在前端；
             若 WER 低而 BLEU 仍低，瓶颈在 MT 或数据稀疏。
             IWSLT 2020 的 Non-native 任务正是用 WER/BLEU 负相关做这一判断。
* COMET / BLEURT —— 基于预训练模型的神经指标，与人工相关性显著高于 BLEU。
             IWSLT 2025 起将其列为并列主指标。本脚本给出调用方式但不内嵌权重
            （需自行 pip install unbabel-comet 并下载 100MB+ 模型）。

用法
----
  # 端到端语音翻译：中文译文 vs 中文参考
  python3.12 st_eval.py --hyp data/demo/e2e.zh --ref data/demo/ref.zh --tgt-lang zh

  # 级联系统：同时看 ASR 端错误率（--asr-hyp 是英文识别结果，--src 是英文参考转写）
  python3.12 st_eval.py --hyp data/demo/cascade.zh --ref data/demo/ref.zh \
      --tgt-lang zh --asr-hyp data/demo/asr.hyp.en --src data/demo/src.en --src-lang en

  # 多系统横向对比（一次跑完并排序）
  python3.12 st_eval.py --run e2e=data/demo/e2e.zh cascade=data/demo/cascade.zh \
      --ref data/demo/ref.zh --tgt-lang zh
"""

import argparse
import json
import os
import sys

try:
    import sacrebleu
except ImportError:
    sys.exit("缺少 sacrebleu：pip install --break-system-packages sacrebleu jieba")

try:
    import jiwer
    HAVE_JIWER = True
except ImportError:
    HAVE_JIWER = False


def read(path):
    with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
        return [l for l in (x.rstrip("\n") for x in f) if l.strip()]


# ------------------------------------------------------------------ 指标
def sent_scores(hyps, refs, tgt_lang):
    """逐句分数，供后续 bootstrap 显著性检验使用。"""
    tok = "zh" if tgt_lang == "zh" else ("ja-mecab" if tgt_lang == "ja" else "13a")
    bleu, chrf, ter = [], [], []
    asian = (tgt_lang == "zh")
    for h, r in zip(hyps, refs):
        b = sacrebleu.corpus_bleu([h], [[r]], tokenize=tok, force=True)
        c = sacrebleu.corpus_chrf([h], [[r]])
        try:
            t = sacrebleu.corpus_ter([h], [[r]], normalized=True,
                                     asian_support=asian, case_sensitive=True)
        except Exception:
            t = None
        bleu.append(b.score)
        chrf.append(c.score)
        ter.append(t.score if t is not None else None)
    return bleu, chrf, ter


def corpus_scores(hyps, refs, tgt_lang):
    tok = "zh" if tgt_lang == "zh" else ("ja-mecab" if tgt_lang == "ja" else "13a")
    b = sacrebleu.corpus_bleu(hyps, [refs], tokenize=tok, force=True)
    c = sacrebleu.corpus_chrf(hyps, [refs])
    out = {"BLEU": b.score, "chrF2": c.score}
    try:
        t = sacrebleu.corpus_ter(hyps, [refs], normalized=True,
                                 asian_support=(tgt_lang == "zh"), case_sensitive=True)
        out["TER"] = t.score
    except Exception:
        out["TER"] = None
    out["_signature"] = signature(tok)
    return out


def signature(tok):
    """SacreBLEU 版本指纹 —— 官方要求随论文一起报告，否则分数不可横向比较。"""
    ver = getattr(sacrebleu, "__version__", "?")
    try:
        from sacrebleu.metrics.bleu import BLEU
        return "BLEU signature: " + BLEU(tokenize=tok).get_signature()
    except Exception:
        return f"BLEU signature: nrefs:1|case:mixed|eff:no|tok:{tok}|smooth:exp|version:sacrebleu-{ver}"


def asr_scores(hyps, refs):
    if not HAVE_JIWER:
        return None
    # jiwer 要求等长对齐，逐句算再平均，避免语料级拼接引入伪删除
    w, c = [], []
    for h, r in zip(hyps, refs):
        try:
            w.append(jiwer.wer(r, h))
            c.append(jiwer.cer(r, h))
        except Exception:
            pass
    if not w:
        return None
    return {"WER%": 100 * sum(w) / len(w), "CER%": 100 * sum(c) / len(c)}


def mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


# ------------------------------------------------------------------ 主流程
def eval_one(name, hyp_path, refs, tgt_lang, asr_hyp=None, src=None, src_lang="en"):
    hyps = read(hyp_path)
    if len(hyps) != len(refs):
        print(f"  !! {name}: 假设 {len(hyps)} 行 != 参考 {len(refs)} 行。"
              f"BLEU 将被静默稀释，请先跑 check_format.py。")
    n = min(len(hyps), len(refs))
    hyps, r_ = hyps[:n], refs[:n]
    cs = corpus_scores(hyps, r_, tgt_lang)
    sb, sc, st = sent_scores(hyps, r_, tgt_lang)
    res = {"name": name, "n": n, **{k: v for k, v in cs.items() if not k.startswith("_")},
           "signature": cs["_signature"]}
    if asr_hyp and src:
        a = asr_scores(read(asr_hyp), read(src))
        if a:
            res.update(a)
    res["_sent_bleu"] = sb
    return res


def main():
    ap = argparse.ArgumentParser(description="离线语音翻译质量评测")
    ap.add_argument("--hyp", help="单系统假设文件")
    ap.add_argument("--run", nargs="*", help="多系统，格式 name=path")
    ap.add_argument("--ref", required=True, help="参考译文")
    ap.add_argument("--tgt-lang", default="zh", help="目标语言 zh/ja/en/...")
    ap.add_argument("--asr-hyp", help="ASR 英文识别假设（级联系统诊断用）")
    ap.add_argument("--src", help="英文参考转写（ASR 参考）")
    ap.add_argument("--src-lang", default="en")
    ap.add_argument("--dump", help="把逐句分数导出为 JSON，供 significance.py 使用")
    a = ap.parse_args()

    refs = read(a.ref)
    runs = []
    if a.run:
        for item in a.run:
            name, path = item.split("=", 1)
            runs.append((name, path))
    elif a.hyp:
        runs.append((os.path.basename(a.hyp), a.hyp))
    else:
        ap.error("需要 --hyp 或 --run")

    print("=" * 78)
    print(" 离线语音翻译质量评测   (sacrebleu %s)" % getattr(sacrebleu, "__version__", "?"))
    print("=" * 78)
    print(f" 参考：{a.ref}  ({len(refs)} 句)   目标语言：{a.tgt_lang}")

    results = []
    for name, path in runs:
        r = eval_one(name, path, refs, a.tgt_lang, a.asr_hyp, a.src, a.src_lang)
        results.append(r)
        print(f"\n---- {name} ----")
        print(f"  句数           : {r['n']}")
        print(f"  BLEU  (↑)      : {r['BLEU']:.2f}")
        print(f"  chrF2 (↑)      : {r['chrF2']:.2f}")
        if r.get("TER") is not None:
            print(f"  TER   (↓)      : {r['TER']:.2f}")
        if "WER%" in r:
            print(f"  WER   (↓)      : {r['WER%']:.2f} %   [ASR 端]")
            print(f"  CER   (↓)      : {r['CER%']:.2f} %   [ASR 端]")

    if len(results) > 1:
        print("\n" + "=" * 78)
        print(" 多系统对比（按 BLEU 降序）")
        print("=" * 78)
        hdr = ["系统", "BLEU↑", "chrF2↑", "TER↓"]
        if "WER%" in results[0]:
            hdr.append("WER%↓")
        print("  " + "".join(f"{h:>12s}" for h in hdr))
        for r in sorted(results, key=lambda x: -x["BLEU"]):
            row = [r["name"], f"{r['BLEU']:.2f}", f"{r['chrF2']:.2f}",
                   f"{r['TER']:.2f}" if r.get("TER") is not None else "-"]
            if "WER%" in r:
                row.append(f"{r['WER%']:.2f}")
            print("  " + "".join(f"{c:>12s}" for c in row))

    print("\n" + results[0]["signature"])
    print("提示：BLEU/TER/chrF 由 SacreBLEU 计算，signature 是官方要求随论文一起报告的"
          "版本指纹（不同 tokenizer/版本不可直接比大小）。")

    if a.dump:
        data = {r["name"]: {k: v for k, v in r.items()
                            if k not in ("_sent_bleu", "signature")} for r in results}
        data["_sentence_level"] = {r["name"]: r["_sent_bleu"] for r in results}
        with open(a.dump, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"\n[OK] 逐句分数已导出 -> {a.dump}")


if __name__ == "__main__":
    main()
