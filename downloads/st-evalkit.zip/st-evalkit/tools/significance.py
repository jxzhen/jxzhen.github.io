#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
语音翻译系统差异的显著性检验（配对 bootstrap + 配对 t 检验）。

为什么必须做
------------
语音翻译的官方测试集通常只有几十句到几百句（MuST-C tst-COMMON 2,641 句，
IWSLT 单语向测试集常在 1,000~3,000 句量级；自建英汉集若只有 30~60 句，
两个系统差 1~2 个 BLEU **极可能只是噪声**）。
只报"我比基线高 1.5 BLEU"而不给置信区间，审稿人和甲方都会质疑。

方法
----
配对 bootstrap：对句对 (i) 重采样 B 次，每次算两个系统均值之差，
用差值的经验分布给置信区间。配对设计消掉了"句子难度"这个公共方差，
比独立两样本检验敏感得多——这在小样本下是关键。

判读
----
95% CI 不包含 0 且 p < 0.05  → 差异可信
否则                          → 只能说"数值更高"，不能说"显著更好"

用法
----
  # 用 st_eval.py 导出的逐句分数
  python3.12 significance.py --dump data/demo/scores.json --a e2e --b cascade --metric BLEU

  # 或直接给两个每行一个分数的文件
  python3.12 significance.py --a-file a.txt --b-file b.txt --metric SubER --lower-better
"""

import argparse
import json
import random
import sys


def load_from_dump(path, name, metric, lower_better):
    with open(path, "r", encoding="utf-8") as f:
        d = json.load(f)
    sl = d.get("_sentence_level", {})
    if name not in sl:
        sys.exit(f"dump 里没有系统 {name}；可用：{list(sl)}")
    vals = sl[name]
    if metric != "BLEU":
        sys.exit("dump 目前只存逐句 BLEU；其它指标请用 --a-file/--b-file 自行导出")
    if lower_better:
        vals = [-v for v in vals]           # 统一成"越大越好"再做差
    return vals


def load_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return [float(x) for x in f if x.strip()]


def bootstrap_paired(a, b, B=10000, seed=42):
    rng = random.Random(seed)
    n = len(a)
    diffs = []
    for _ in range(B):
        s = 0.0
        for _ in range(n):
            i = rng.randrange(n)
            s += a[i] - b[i]
        diffs.append(s / n)
    diffs.sort()
    lo = diffs[int(0.025 * B)]
    hi = diffs[int(0.975 * B) - 1]
    obs = sum(a) / n - sum(b) / n
    # 双侧 p：重采样差值跨越 0 的比例（对 obs 做中心化）
    shifted = [d - obs for d in diffs]
    cnt = sum(1 for d in shifted if (d >= abs(obs)) or (d <= -abs(obs)))
    p = min(1.0, cnt / B)
    return obs, lo, hi, p, diffs


def paired_t(a, b):
    try:
        from statistics import mean, stdev
        d = [x - y for x, y in zip(a, b)]
        n = len(d)
        m = mean(d)
        s = stdev(d)
        if s == 0 or n < 2:
            return None, None
        t = m / (s / (n ** 0.5))
        return t, n - 1
    except Exception:
        return None, None


def main():
    ap = argparse.ArgumentParser(description="语音翻译差异显著性检验")
    ap.add_argument("--dump", help="st_eval.py --dump 导出的 JSON")
    ap.add_argument("--a", help="dump 中的系统 A 名")
    ap.add_argument("--b", help="dump 中的系统 B 名")
    ap.add_argument("--a-file", help="A 的逐句分数文件")
    ap.add_argument("--b-file", help="B 的逐句分数文件")
    ap.add_argument("--metric", default="BLEU")
    ap.add_argument("--lower-better", action="store_true",
                    help="指标越小越好（SubER/WER/TER/CER/延迟）")
    ap.add_argument("--B", type=int, default=10000)
    a = ap.parse_args()

    if a.dump:
        A = load_from_dump(a.dump, a.a, a.metric, a.lower_better)
        B = load_from_dump(a.dump, a.b, a.metric, a.lower_better)
        an, bn = a.a, a.b
    elif a.a_file and a.b_file:
        A, B = load_file(a.a_file), load_file(a.b_file)
        if a.lower_better:
            A = [-v for v in A]
            B = [-v for v in B]
        an, bn = a.a_file, a.b_file
    else:
        ap.error("需要 --dump + --a/--b，或 --a-file/--b-file")

    n = min(len(A), len(B))
    if len(A) != len(B):
        print(f"  !! 长度不一致（{len(A)} vs {len(B)}），截断到 {n} 并配对")
    A, B = A[:n], B[:n]

    obs, lo, hi, p, diffs = bootstrap_paired(A, B, a.B)
    t, df = paired_t(A, B)

    print("=" * 78)
    print(f" 显著性检验  指标={a.metric}   n={n} 句   B={a.B}")
    print("=" * 78)
    print(f"  系统 A = {an}")
    print(f"  系统 B = {bn}")
    print(f"\n  观测差值 (A−B)      : {obs:+.4f}")
    print(f"  95% 置信区间        : [{lo:+.4f}, {hi:+.4f}]")
    print(f"  bootstrap 双侧 p    : {p:.4f}")
    if t is not None:
        print(f"  配对 t 统计量       : {t:+.4f}  (df={df})")
    sd = (sum((d - obs) ** 2 for d in diffs) / max(len(diffs) - 1, 1)) ** 0.5
    print(f"  差值分布标准差      : {sd:.4f}")

    print("\n  判读：")
    if lo > 0 or hi < 0:
        print(f"    95% CI 不包含 0 → 差异{'显著' if p < 0.05 else '方向稳定但 p 未过 0.05'}。"
              f"  可以写“A 显著{'优于' if obs > 0 else '劣于'} B”。")
    else:
        print("    95% CI 包含 0 → **不能**声称 A 优于 B。")
        print("    规范写法：“A 在数值上高于 B（+X），但差异未达统计显著（95% CI 含 0）”。")
    print("\n  提醒：bootstrap 只刻画“测试集抽样”这一层随机性。"
          "解码/训练随机性需要多种子重复实验，别混为一谈。")


if __name__ == "__main__":
    main()
