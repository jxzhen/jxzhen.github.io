#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成任务3（语音机器翻译）评测工具包的合成演示数据。

设计原则
--------
* 数据**完全合成**，不声称来自任何真实语料，仅用于跑通评测流水线、
  验证脚本能正确区分"好/差"系统（这一点与任务1用真实 NIST qrels 验证
  oracle/shuffle/doclevel 的思路一致：脚本必须能被反例证伪）。
* 但**生成规律**严格参照 IWSLT 官方赛道的真实现象：
  1. 级联系统（ASR→MT）的译文质量随 ASR 词错误率单调下降；
  2. 端到端系统不受 ASR 错误传播影响，但在长句/罕见词上更弱；
  3. 字幕系统的"逐字转写"输出会违反 CPS/CPL/LPB 合规约束，
     经压缩（condensation）后 SubER 与合规率同时改善（IWSLT 2026 字幕赛道已验证）。
* 固定随机种子 → 结果可复现。

输出
----
  data/demo/manifest.tsv      音频片段清单（seg_id / wav / start / end / duration）
  data/demo/src.en            英文参考转写（语音里"实际说的话"）
  data/demo/ref.zh            中文参考译文（4 句块对应 1 条人工参考）
  data/demo/asr.hyp.en        英文 ASR 识别假设（含识别错误）
  data/demo/cascade.zh        级联系统输出（ASR 错误会传播到译文）
  data/demo/e2e.zh            端到端系统输出
  data/demo/ref.srt           参考字幕（合规）
  data/demo/hyp_raw.srt       逐字转写字幕（不合规）
  data/demo/hyp_cond.srt      压缩后字幕（合规）
  data/demo/simul_waits.jsonl 同传策略的 g(t) 序列（wait-k / offline）
"""

import json
import os
import random

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(HERE), "data", "demo")

# ---------------------------------------------------------------- 英汉平行句对
SRC_EN = [
    "So today I want to talk about how machines learn to understand human speech.",
    "This is a problem that has puzzled researchers for more than fifty years.",
    "When you speak, your vocal tract produces a very complex acoustic signal.",
    "That signal carries not only words, but also emotion and intention.",
    "A translation system has to recover all of that from sound waves.",
    "The traditional approach splits the task into two separate stages.",
    "First, a speech recognizer turns audio into text in the source language.",
    "Then a machine translation model converts that text into the target language.",
    "This cascade is simple, and each component can be trained on plenty of data.",
    "But errors made by the recognizer are passed directly to the translator.",
    "And there is no way for the translator to correct them later.",
    "An end to end model tries to avoid this problem entirely.",
    "It maps the audio signal directly to the translated sentence.",
    "In theory this reduces error propagation and simplifies the pipeline.",
    "In practice it is much harder to train, because paired data is scarce.",
    "We have millions of hours of transcribed speech in English.",
    "We also have billions of sentences of parallel text for translation.",
    "But speech with a direct translation in another language is extremely rare.",
    "Most of it comes from parliamentary recordings and a few lecture collections.",
    "To build a large corpus, we started from English audio and bilingual subtitles.",
    "The subtitles give us a rough alignment between sound and meaning.",
    "We then align the audio with the subtitle text using a forced aligner.",
    "After that, we align the English subtitle with its Chinese translation.",
    "Both alignment steps introduce noise, so we filter aggressively.",
    "Segments that are too short or too long are discarded.",
    "Segments whose speech and text lengths disagree are also removed.",
    "What survives is about four hundred hours of clean English Chinese speech.",
    "Our next question was how to represent meaning across languages and modalities.",
    "A picture of a dog and the spoken word dog should end up close together.",
    "So should the written word dog in English and its translation in Chinese.",
    "We train a shared space where all three modalities are projected.",
    "Images come from a large captioning collection with human written descriptions.",
    "Speech and text come from the parallel corpus we just built.",
    "The segmentation of semantic units turned out to matter a great deal.",
    "Words are not the right unit for every language or every modality.",
    "For speech, we experimented with acoustic units discovered without supervision.",
    "For text, subword pieces learned from data worked reasonably well.",
    "Multi granularity composition lets the model combine small units into larger ones.",
    "With this representation, translation quality improved by more than two points.",
    "The gain was largest on long sentences and on sentences with rare words.",
]

REF_ZH = [
    "所以今天我想谈谈机器是如何学会理解人类语音的。",
    "这是一个困扰了研究者五十多年的问题。",
    "当你说话时，你的声道会产生非常复杂的声学信号。",
    "这个信号不仅承载着词语，还承载着情绪和意图。",
    "翻译系统必须从声波中还原出这一切。",
    "传统做法把这项任务拆分成两个独立的阶段。",
    "首先，语音识别器把音频转成源语言的文本。",
    "然后机器翻译模型再把这段文本转换成目标语言。",
    "这种级联方式很简单，而且每个组件都能用大量数据训练。",
    "但识别器犯下的错误会直接传给翻译器。",
    "而且翻译器在之后没有任何办法纠正它们。",
    "端到端模型试图彻底避免这个问题。",
    "它把音频信号直接映射为翻译后的句子。",
    "理论上这能减少误差传播，并简化整个流程。",
    "实际上它训练起来困难得多，因为平行数据非常稀缺。",
    "我们有数百万小时的英文转写语音。",
    "我们也有数十亿句用于翻译的平行文本。",
    "但带有另一种语言直接翻译的语音却极为罕见。",
    "其中大部分来自议会录音和少量演讲合集。",
    "为了构建大规模语料，我们从英文音频和双语字幕出发。",
    "字幕为我们提供了声音与意义之间的粗略对齐。",
    "随后我们用强制对齐工具把音频与字幕文本对齐。",
    "在那之后，我们把英文字幕与它的中文译文对齐。",
    "两个对齐步骤都会引入噪声，因此我们要做严格过滤。",
    "过短或过长的片段会被丢弃。",
    "语音长度与文本长度不一致的片段同样会被剔除。",
    "最终留下的是大约四百小时干净的英汉语音数据。",
    "我们的下一个问题是，如何在语言和模态之间表示意义。",
    "一张狗的图片和说出的狗这个词，最终应该彼此接近。",
    "英文里的狗和它对应的中文翻译也应该如此。",
    "我们训练一个共享空间，把三种模态都投影进去。",
    "图像来自一个带人工描述说明的大型图像描述数据集。",
    "语音和文本则来自我们刚刚构建的平行语料。",
    "语义单元的切分方式被证明非常关键。",
    "词并不是每种语言或每种模态下都合适的单元。",
    "对于语音，我们尝试了以无监督方式发现的声学单元。",
    "对于文本，从数据中学习到的子词片段效果还不错。",
    "多粒度组合让模型能够把小单元组合成更大的单元。",
    "借助这种表示，翻译质量提升了两个百分点以上。",
    "在长句和含有罕见词的句子上，提升最为明显。",
]

# ASR 混淆词表（模拟真实识别错误：同音/近形/虚词遗漏）
SUBSTITUTE = ["speach", "single", "word", "text", "model", "data", "system"]
FILLER = ["uh", "you know", "I mean"]

assert len(SRC_EN) == len(REF_ZH) == 40, "句对数量必须一致"


def degrade_asr(text, rng):
    """按词级操作注入 ASR 错误：删除 / 替换 / 插入填充语。"""
    toks = text.split()
    out = []
    for t in toks:
        r = rng.random()
        if r < 0.035:                       # 删除
            continue
        if r < 0.035 + 0.055:               # 替换
            out.append(rng.choice(SUBSTITUTE))
            continue
        out.append(t)
        if rng.random() < 0.015:            # 插入
            out.append(rng.choice(FILLER))
    # 句末标点丢失（真实 ASR 常见问题：无标点输入）
    return " ".join(out).rstrip(".,")


def degrade_zh(ref, rng, strength):
    """按字符级操作注入译文错误，strength 越大错误越多。"""
    chars = list(ref)
    n_err = max(0, int(round(len(chars) * strength / 100.0)))
    for _ in range(n_err):
        if len(chars) < 4:
            break
        i = rng.randrange(len(chars))
        op = rng.random()
        if op < 0.5:                        # 替换
            chars[i] = rng.choice("的了是这不一有个我们也就")
        elif op < 0.8:                      # 删除
            del chars[i]
        else:                               # 插入
            chars.insert(i, rng.choice("的了这"))
    return "".join(chars)


# ------------------------------------------------------------------ SRT 生成
def fmt_ts(sec):
    """毫秒必须整体取整后再拆分，否则 0.9996s 会溢出成 ',1000'（非法 SRT）。"""
    total = int(round(sec * 1000))
    h, rem = divmod(total, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def write_srt(path, blocks):
    """blocks: [(start, end, [line1, line2]), ...]"""
    with open(path, "w", encoding="utf-8") as f:
        for i, (st, en, lines) in enumerate(blocks, 1):
            f.write(f"{i}\n{fmt_ts(st)} --> {fmt_ts(en)}\n")
            for ln in lines:
                f.write(ln + "\n")
            f.write("\n")


def chunk_zh(text, cpl):
    """把中文按每行 cpl 字切分为最多 2 行。"""
    return [text[i:i + cpl] for i in range(0, len(text), cpl)]


def main():
    os.makedirs(OUT, exist_ok=True)
    rng = random.Random(20180901)           # 项目起始年月，固定种子

    # ---------------- 1. 音频清单 + 转写 / 译文 / 系统输出 ----------------
    manifest = ["seg_id\twav\tstart\tend\tduration"]
    asr_hyp, cascade, e2e = [], [], []
    t = 0.0
    for i, (en, zh) in enumerate(zip(SRC_EN, REF_ZH)):
        dur = max(1.2, 0.42 * len(en.split()) + rng.uniform(-0.4, 0.4))
        st, en_t = t, t + dur
        t = en_t + rng.uniform(0.1, 0.5)
        manifest.append(f"seg{i:03d}\ttalk01.wav\t{st:.3f}\t{en_t:.3f}\t{dur:.3f}")

        a = degrade_asr(en, rng)
        asr_hyp.append(a)

        # 级联：ASR 错误率直接决定译文退化强度（错误传播）
        asr_err = abs(len(a.split()) - len(en.split())) + \
            sum(1 for x, y in zip(a.split(), en.split()) if x != y)
        cascade_strength = 4.0 + 2.2 * asr_err
        cascade.append(degrade_zh(zh, rng, cascade_strength))

        # 端到端：无错误传播，但长句更弱
        nword = len(en.split())
        e2e_strength = 3.0 + (0.55 * max(0, nword - 12))
        e2e.append(degrade_zh(zh, rng, e2e_strength))

    def w(name, lines):
        with open(os.path.join(OUT, name), "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

    w("manifest.tsv", manifest)
    w("src.en", SRC_EN)
    w("ref.zh", REF_ZH)
    w("asr.hyp.en", asr_hyp)
    w("cascade.zh", cascade)
    w("e2e.zh", e2e)

    # ---------------- 2. 字幕（研究内容5）----------------
    # 参考字幕：合规（CPL<=16, LPB<=2, CPS<=9）
    ref_blocks, t0 = [], 0.0
    for zh in REF_ZH:
        lines = chunk_zh(zh, 16)[:2]
        n = sum(len(x) for x in lines)
        dur = max(1.0, n / 7.5)             # 7.5 字/秒，低于 9 的上限
        ref_blocks.append((t0, t0 + dur, lines))
        t0 += dur + 0.08
    write_srt(os.path.join(OUT, "ref.srt"), ref_blocks)

    # 逐字转写字幕：超长行 / 过快（不合规）+ 分段不同 + 时间轴整体漂移
    # （这正是"ASR 直出"字幕的典型形态：BLEU 未必低，但 SubER 与合规率都很差）
    raw_blocks, t1 = [], 0.0
    for zh in REF_ZH:
        long_text = zh.rstrip("。") + "，也就是说这一点非常重要。"
        lines = chunk_zh(long_text, 26)      # 26 字/行 → 违反 CPL(<=16)
        n = sum(len(x) for x in lines)
        dur = max(0.6, n / 16.0)             # 16 字/秒 → 违反 CPS(<=9)
        raw_blocks.append((t1 + 0.25, t1 + 0.25 + dur, lines))
        t1 += dur + 0.05
    write_srt(os.path.join(OUT, "hyp_raw.srt"), raw_blocks)

    # 压缩后字幕：沿用参考的时间轴（真实系统经强制对齐后本应如此），
    # 文本做轻度压缩，分段合规。加 ±0.03s 抖动模拟对齐误差，但不产生累积漂移
    # ——累积时间漂移会让 SubER 静默爆表，这是要避免的工程坑，不是要演示的效果。
    cond_blocks = []
    for (st, en, _), zh in zip(ref_blocks, REF_ZH):
        # 压缩会丢一点信息（真实 LLM 压缩同样有损），强度逐句不同，
        # 这样 SubER 会是一个小的非零值而非 0 —— 0 分看起来像"用了参考当假设"
        short = degrade_zh(zh.rstrip("。"), rng, rng.choice([0, 4, 8, 12])) + "。"
        lines = chunk_zh(short, 16)[:2]
        j = rng.uniform(-0.03, 0.03)
        st2 = max(0.0, st + j)                  # 钳位：不能出现负时间戳
        en2 = max(st2 + 0.1, en + j)
        cond_blocks.append((st2, en2, lines))
    write_srt(os.path.join(OUT, "hyp_cond.srt"), cond_blocks)

    # ---------------- 3. 同传 g(t) 序列（研究内容4）----------------
    # g(t) = 生成第 t 个目标词时，已经读入的源语音单元数
    simul = []
    for i, (en, zh) in enumerate(zip(SRC_EN, REF_ZH)):
        src_len = len(en.split())
        tgt_len = len(list(zh))
        for policy, k in (("wait-1", 1), ("wait-3", 3), ("wait-5", 5), ("wait-9", 9)):
            g = [min(src_len, k + int(round(t * src_len / tgt_len)))
                 for t in range(1, tgt_len + 1)]
            simul.append({"seg_id": f"seg{i:03d}", "policy": policy,
                          "src_len": src_len, "tgt_len": tgt_len, "g": g})
        # 离线（等全部说完再翻）
        simul.append({"seg_id": f"seg{i:03d}", "policy": "offline",
                      "src_len": src_len, "tgt_len": tgt_len,
                      "g": [src_len] * tgt_len})
    with open(os.path.join(OUT, "simul_waits.jsonl"), "w", encoding="utf-8") as f:
        for r in simul:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    print(f"[OK] 演示数据已生成 -> {OUT}")
    for fn in sorted(os.listdir(OUT)):
        p = os.path.join(OUT, fn)
        print(f"  {fn:22s} {os.path.getsize(p):>8,d} B")


if __name__ == "__main__":
    main()
