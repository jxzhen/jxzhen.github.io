#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
同声传译延迟评测（对应研究内容4：端点检测 + 增量翻译降低延迟）。

为什么"翻译质量"不足以评价同传
------------------------------
同传系统的输出质量与延迟天然互斥：等得越久翻得越准。
只报 BLEU 等于鼓励"等全部说完再翻"，那不是同传。
IWSLT 从 2018 年起把 Simultaneous 设为常设赛道，官方统一用
**SimulEval**（Formerly SimulTrans, FBK/CMU）计算延迟。

输入约定
--------
g(t) = 生成第 t 个目标词时，已经读入的源语音单元数。
这是一切延迟指标的公共输入（SimulEval 的 delays 也是它的等价形式）。

实现的指标
----------
AL      Average Lagging（Ma et al. 2019，IWSLT 沿用至今的经典主指标）
        τ = min{t : g(t) = |x|}   （源端读完的时刻）
        AL = (1/τ) Σ_{t=1..τ} [ g(t) − (t−1)·|x|/|y| ]
        单位：源端单元数。缺点：依赖 τ，对"多生成 token"敏感。
DAL     Differentiable Average Lagging（Arivazhagan et al. 2019）
        与 AL 同式，但分母固定为 |y|（不依赖 τ），因此可微分、可直接进 loss。
AP      Average Proportion（Cho & Esipova 2016）
        AP = (1/(|x|·|y|)) Σ_{t=1..|y|} g(t)，归一化到 [0,1]，越小越"流式"。
LAAL    Length-Adaptive AL（Papi et al. 2022）
        把 AL 里的 |y| 换成 l_ω = ω·|y|，缓解"译文长度与目标长度不一致"导致的偏差。
StreamLAAL = LAAL 在 ω 网格上的均值（IWSLT 2025 同传赛道采用）。
SO      Starting Offset = g(1)，首个目标词吐出前读了多少源端单元（首字延迟）。

诚实声明
--------
LAAL / StreamLAAL 的网格取值与边界处理在不同实现里有细微差异。
本脚本用于**离线复核与消融分析**；正式提交一律以官方 SimulEval 输出为准，
论文里请写 "computed with SimulEval"。

用法
----
  python3.12 latency.py --waits data/demo/simul_waits.jsonl
  python3.12 latency.py --waits data/demo/simul_waits.jsonl --src-duration 2.6 \
      --quality data/demo/scores.json
"""

import argparse
import json
import os


def first_read_all(g, src_len):
    """τ = 源端首次被读完的目标位置；若始终没读完，取末位。"""
    for i, v in enumerate(g, 1):
        if v >= src_len:
            return i
    return len(g)


def metric_AL(g, src_len, tgt_len):
    tau = first_read_all(g, src_len)
    s = 0.0
    for t in range(1, tau + 1):
        gi = g[t - 1] if t - 1 < len(g) else src_len
        s += gi - (t - 1) * src_len / max(tgt_len, 1)
    return s / max(tau, 1)


def metric_DAL(g, src_len, tgt_len):
    s = 0.0
    for t in range(1, tgt_len + 1):
        gi = min(g[t - 1], src_len) if t - 1 < len(g) else src_len
        s += gi - (t - 1) * src_len / max(tgt_len, 1)
    return s / max(tgt_len, 1)


def metric_AP(g, src_len, tgt_len):
    tot = sum(min(v, src_len) for v in g)
    return tot / max(src_len * tgt_len, 1)


def metric_LAAL(g, src_len, tgt_len, omega=1.0):
    tau = first_read_all(g, src_len)
    l_omega = max(omega * tgt_len, 1e-9)
    s = 0.0
    for t in range(1, tau + 1):
        gi = g[t - 1] if t - 1 < len(g) else src_len
        s += gi - (t - 1) * src_len / l_omega
    return s / max(tau, 1)


def metric_StreamLAAL(g, src_len, tgt_len, grid=None):
    if grid is None:
        grid = [0.5 + 0.1 * i for i in range(16)]     # ω ∈ [0.5, 2.0]
    vals = [metric_LAAL(g, src_len, tgt_len, w) for w in grid]
    return sum(vals) / len(vals)


def metric_SO(g):
    return float(g[0]) if g else 0.0


def all_metrics(rec):
    g, x, y = rec["g"], rec["src_len"], rec["tgt_len"]
    return {
        "AL": metric_AL(g, x, y),
        "DAL": metric_DAL(g, x, y),
        "AP": metric_AP(g, x, y),
        "LAAL": metric_LAAL(g, x, y),
        "StreamLAAL": metric_StreamLAAL(g, x, y),
        "SO": metric_SO(g),
    }


def main():
    ap = argparse.ArgumentParser(description="同传延迟评测")
    ap.add_argument("--waits", required=True, help="g(t) 序列 JSONL")
    ap.add_argument("--src-duration", type=float,
                    help="源句平均时长（秒），用于把 AL 换算成秒：AL_s = AL * dur/|x|")
    ap.add_argument("--quality", help="st_eval.py 导出的 JSON，用于拼质量-延迟表")
    ap.add_argument("--json", help="导出 JSON")
    a = ap.parse_args()

    recs = []
    with open(a.waits, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                recs.append(json.loads(line))

    by_pol = {}
    for r in recs:
        by_pol.setdefault(r["policy"], []).append(all_metrics(r))

    print("=" * 78)
    print(" 同传延迟评测（源端单元为单位；越低越实时）")
    print("=" * 78)
    print(f" 样本：{len(recs)} 条 g(t) 序列，{len(by_pol)} 个策略")

    keys = ["AL", "DAL", "AP", "LAAL", "StreamLAAL", "SO"]
    if a.src_duration:
        keys.append("AL_sec")

    rows = []
    for pol, ms in by_pol.items():
        agg = {k: sum(m[k] for m in ms) / len(ms) for k in
               ["AL", "DAL", "AP", "LAAL", "StreamLAAL", "SO"]}
        # AL 换算成秒：源端单元 → 秒
        if a.src_duration:
            per_src = a.src_duration / max(
                sum(r["src_len"] for r in recs if r["policy"] == pol) /
                max(len(ms), 1), 1)
            agg["AL_sec"] = agg["AL"] * per_src
        rows.append((pol, len(ms), agg))

    rows.sort(key=lambda x: x[2]["AL"])
    print("\n  " + "".join(f"{h:>12s}" for h in ["策略", "n"] + keys))
    for pol, n, agg in rows:
        print("  " + f"{pol:>12s}{n:>12d}" +
              "".join(f"{agg[k]:>12.3f}" for k in keys))

    if a.quality:
        with open(a.quality, "r", encoding="utf-8") as f:
            q = json.load(f)
        print("\n---- 质量-延迟权衡 ----")
        print("  " + "".join(f"{h:>14s}" for h in ["策略", "AL↓", "BLEU↑", "BLEU/AL↑"]))
        for pol, n, agg in rows:
            bleu = None
            for k, v in q.items():
                if k.startswith("_"):
                    continue
                if pol in k or k in pol:
                    bleu = v.get("BLEU")
            if bleu is None:
                print(f"  {pol:>14s}{agg['AL']:>14.3f}{'n/a':>14s}{'n/a':>14s}")
            else:
                print(f"  {pol:>14s}{agg['AL']:>14.3f}{bleu:>14.2f}"
                      f"{bleu / max(agg['AL'], 1e-9):>14.2f}")
        print("\n  注：BLEU/AL 只是直观权衡参考，不是官方指标。"
              "官方做法是画 quality–latency 曲线并报告曲线下的工作区间。")

    print("\n  AL/DAL/LAAL/SO 单位 = 源端单元数；AP 无量纲 ∈ [0,1]。")
    print("  提交请以官方 SimulEval 输出为准：https://github.com/facebookresearch/SimulEval")

    if a.json:
        with open(a.json, "w", encoding="utf-8") as f:
            json.dump({pol: agg for pol, n, agg in rows}, f, ensure_ascii=False, indent=2)
        print(f"\n[OK] 导出 -> {a.json}")


if __name__ == "__main__":
    main()
