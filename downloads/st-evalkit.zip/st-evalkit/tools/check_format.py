#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
提交前体检脚本（语音翻译 / 字幕赛道）。

为什么必须有这一步
------------------
语音翻译评测里最致命的失败不是"分数低"，而是"分数看起来正常其实算错了"。
四个高频静默故障：

[A] 假设与参考**行数不一致**
    BLEU 是按语料级 n-gram 统计计算的，多一行少一行不会报错，只会悄悄稀释。
    IWSLT 官方因此要求用 mwerSegmenter / mweralign 对假设做重分段后再评分。

[B] 假设与参考**句子不对应**（错位一行）
    同上，不报错，但 BLEU 会掉到接近 0，且你查不出原因。

[C] 字幕 SRT 时间轴不单调 / 重叠 / 格式非法
    SubER 依赖时间戳做 shift 对齐。文档明确写了：
    "Make sure that there is no constant time offset between the timestamps
     in hypothesis and reference as this will lead to incorrect scores."
    恒定时间偏移会让 SubER 静默算错。

[D] 音频清单与文本清单对不上（数据集构建阶段）
    研究内容1做强制对齐时，片段重叠、时长异常、空文本会一路污染到训练集。

用法
----
  python3.12 check_format.py --hyp e2e.zh --ref ref.zh --lang-pair en-zh
  python3.12 check_format.py --srt hyp_cond.srt --srt-ref ref.srt
  python3.12 check_format.py --manifest manifest.tsv --text src.en

退出码 0 = 通过；1 = 有 ERROR 级问题（禁止提交）。
"""

import argparse
import os
import re
import sys

ok, warn, err = [], [], []


def O(m):
    ok.append(m)
    print("  [OK]   " + m)


def W(m):
    warn.append(m)
    print("  [WARN] " + m)


def E(m):
    err.append(m)
    print("  [ERR]  " + m)


# --------------------------------------------------------------- 通用读入
def read_lines(path):
    with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
        raw = f.read()
    if "�" in raw:
        W(f"{os.path.basename(path)}: 含无法解码字节（疑似非 UTF-8），请统一转 UTF-8")
    return [l for l in raw.splitlines()]


def nonempty(lines):
    return [l for l in lines if l.strip()]


# --------------------------------------------------------------- [A][B] 文本
def check_text_pair(hyp_path, ref_path, lang_pair):
    print(f"\n[A] 翻译假设 vs 参考  ({os.path.basename(hyp_path)} / {os.path.basename(ref_path)})")
    hyp = nonempty(read_lines(hyp_path))
    ref = nonempty(read_lines(ref_path))
    print(f"      假设 {len(hyp)} 行 / 参考 {len(ref)} 行")

    if len(hyp) != len(ref):
        E(f"行数不一致（{len(hyp)} vs {len(ref)}）。BLEU 会被静默稀释，"
          f"且不会报错。请检查分段，或用 mwerSegmenter/mweralign 重分段。")
    else:
        O("行数一致")

    if not hyp:
        E("假设文件为空")
        return
    if not ref:
        E("参考文件为空")
        return

    # 长度比例合理性（同语言对下译文字符数应与参考同量级）
    lh = sum(len(x) for x in hyp) / len(hyp)
    lr = sum(len(x) for x in ref) / len(ref)
    ratio = lh / max(lr, 1e-9)
    print(f"      平均长度：假设 {lh:.1f} 字 / 参考 {lr:.1f} 字 （比值 {ratio:.3f}）")
    if ratio < 0.5 or ratio > 2.0:
        E(f"译文总长与参考相差过大（比值 {ratio:.2f}）。"
          f"极可能是句子错位、分段粒度不一致，或语言方向搞反了。")
    elif ratio < 0.75 or ratio > 1.35:
        W(f"译文长度与参考偏离较多（比值 {ratio:.2f}），建议人工抽查 10 句。")
    else:
        O("译文长度与参考同量级")

    # 空行/超短行
    short_h = sum(1 for x in hyp if len(x.strip()) < 2)
    if short_h:
        W(f"{short_h} 行译文长度 < 2（空译文会拉低 BLEU，请确认是否解码失败）")
    else:
        O("无空译文")

    # 语言方向粗检
    tgt = lang_pair.split("-")[-1] if lang_pair else ""
    if tgt == "zh":
        zh_h = sum(1 for x in hyp if re.search(r"[一-鿿]", x)) / len(hyp)
        if zh_h < 0.5:
            E(f"目标语言声明为 zh，但仅 {zh_h:.0%} 的译文行含汉字 —— 语言方向可能搞反。")
        else:
            O(f"目标语言一致性：{zh_h:.0%} 的行含汉字")
    elif tgt == "en":
        en_h = sum(1 for x in hyp if re.search(r"[A-Za-z]", x)) / len(hyp)
        if en_h < 0.5:
            E(f"目标语言声明为 en，但仅 {en_h:.0%} 的译文行含拉丁字母。")
        else:
            O(f"目标语言一致性：{en_h:.0%} 的行含拉丁字母")

    # 重复行（解码塌缩的典型症状）
    dup = len(hyp) - len(set(hyp))
    if dup > len(hyp) * 0.1:
        E(f"{dup} 行完全重复（>{10}%）。典型症状：解码塌缩或文件被重复拼接。")
    elif dup:
        W(f"{dup} 行完全重复，请确认是否有意。")
    else:
        O("无重复行")


# --------------------------------------------------------------- [C] 字幕 SRT
TS = re.compile(r"^(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})$")


def parse_srt(path):
    """返回 [(idx, start, end, [lines])]，解析失败抛 ValueError。"""
    lines = read_lines(path)
    blocks, i = [], 0
    while i < len(lines):
        while i < len(lines) and not lines[i].strip():
            i += 1
        if i >= len(lines):
            break
        if not lines[i].strip().isdigit():
            raise ValueError(f"第 {i+1} 行应为数字序号，实为: {lines[i][:40]!r}")
        idx = int(lines[i].strip())
        i += 1
        if i >= len(lines):
            raise ValueError(f"序号 {idx} 后缺少时间轴行")
        m = TS.match(lines[i].strip())
        if not m:
            raise ValueError(f"序号 {idx} 时间轴格式非法: {lines[i][:60]!r}")
        h1, m1, s1, ms1, h2, m2, s2, ms2 = map(int, m.groups())
        st = h1 * 3600 + m1 * 60 + s1 + ms1 / 1000.0
        en = h2 * 3600 + m2 * 60 + s2 + ms2 / 1000.0
        i += 1
        txt = []
        while i < len(lines) and lines[i].strip():
            txt.append(lines[i])
            i += 1
        blocks.append((idx, st, en, txt))
    return blocks


def check_srt(path, ref_path=None):
    print(f"\n[C] 字幕文件  ({os.path.basename(path)})")
    try:
        blocks = parse_srt(path)
    except ValueError as e:
        E(f"SRT 解析失败：{e}")
        return None
    print(f"      共 {len(blocks)} 个字幕块")

    # 序号连续
    idxs = [b[0] for b in blocks]
    if idxs != list(range(1, len(blocks) + 1)):
        E("序号不连续（应从 1 递增）。SubER 与多数播放器都依赖序号。")
    else:
        O("序号连续")

    # 时间合法性 + 单调 + 重叠
    bad_dur = sum(1 for _, st, en, _ in blocks if en <= st)
    if bad_dur:
        E(f"{bad_dur} 个块 end <= start")
    else:
        O("所有块 end > start")

    nonmono = sum(1 for i in range(1, len(blocks)) if blocks[i][1] < blocks[i - 1][1])
    if nonmono:
        E(f"{nonmono} 处起始时间回退（时间轴不单调）")
    else:
        O("起始时间单调递增")

    ovl = sum(1 for i in range(1, len(blocks))
              if blocks[i][1] < blocks[i - 1][2] - 1e-6)
    if ovl:
        E(f"{ovl} 处相邻块时间重叠")
    else:
        O("相邻块无时间重叠")

    # 空文本块
    empty = sum(1 for b in blocks if not b[3])
    if empty:
        E(f"{empty} 个块没有文本")
    else:
        O("无空文本块")

    # 时长过短（不可读）
    too_short = sum(1 for _, st, en, _ in blocks if en - st < 0.4)
    if too_short:
        W(f"{too_short} 个块时长 < 0.4s（低于人类最低可读时长）")
    else:
        O("所有块时长 >= 0.4s")

    # 与参考对比：块数 / 恒定时间偏移
    if ref_path:
        try:
            rb = parse_srt(ref_path)
        except ValueError as e:
            E(f"参考 SRT 解析失败：{e}")
            return blocks
        print(f"      参考 {len(rb)} 块 / 假设 {len(blocks)} 块")
        if abs(len(rb) - len(blocks)) / max(len(rb), 1) > 0.3:
            W("块数与参考相差 >30%。SubER 允许分段不同（它就是要评估分段），"
              "但差异过大通常意味着用错了参考文件。")
        else:
            O("块数与参考同量级")
        # 恒定偏移检测（SubER 官方文档点名的坑）
        n = min(len(rb), len(blocks))
        if n >= 5:
            offs = [blocks[i][1] - rb[i][1] for i in range(n)]
            mean = sum(offs) / n
            var = sum((o - mean) ** 2 for o in offs) / n
            if abs(mean) > 0.2 and var < 0.05:
                E(f"检测到恒定时间偏移 {mean:+.2f}s（同序号块偏移几乎一致）。"
                  f"SubER 文档明确指出恒定偏移会导致分数错误 —— 请先校正时间轴。")
            else:
                O(f"未检测到恒定时间偏移（平均 {mean:+.2f}s，方差 {var:.3f}）")
    return blocks


# --------------------------------------------------------------- [D] 清单
def check_manifest(manifest, text_path=None):
    print(f"\n[D] 音频清单  ({os.path.basename(manifest)})")
    rows = [l.split("\t") for l in read_lines(manifest) if l.strip()]
    hdr = rows[0]
    body = rows[1:]
    print(f"      列: {hdr} / 数据 {len(body)} 行")
    if len(hdr) < 5:
        E("清单列数不足，建议 seg_id / wav / start / end / duration")
        return
    bad = []
    prev_end = None
    for r in body:
        try:
            st, en = float(r[2]), float(r[3])
        except Exception:
            bad.append(r[0] if r else "?")
            continue
        if en <= st:
            bad.append(r[0])
        if prev_end is not None and st < prev_end - 1e-6:
            W(f"片段 {r[0]} 起始 {st:.3f} < 前一片段结束 {prev_end:.3f}（时间轴重叠）")
            prev_end = None
        prev_end = en if prev_end is None else max(prev_end, en)
    if bad:
        E(f"{len(bad)} 行时间非法或 end<=start: {bad[:5]}")
    else:
        O("所有片段时间合法")

    durs = []
    for r in body:
        try:
            durs.append(float(r[4]))
        except Exception:
            pass
    if durs:
        print(f"      总时长 {sum(durs)/3600:.3f} h，"
              f"均值 {sum(durs)/len(durs):.2f}s，"
              f"范围 {min(durs):.2f}~{max(durs):.2f}s")
        short = sum(1 for d in durs if d < 0.5)
        long_ = sum(1 for d in durs if d > 30)
        if short:
            W(f"{short} 个片段 < 0.5s（强制对齐不可靠，建议在构建阶段丢弃）")
        if long_:
            W(f"{long_} 个片段 > 30s（超出典型训练片段长度，建议再切分）")
        if not short and not long_:
            O("片段时长均在 [0.5s, 30s] 合理区间")

    if text_path:
        tl = nonempty(read_lines(text_path))
        if len(tl) != len(body):
            E(f"文本行数 {len(tl)} != 清单行数 {len(body)} —— 音视频与句子未一一对齐，"
              f"这正是研究内容1要解决的对齐问题，必须先修。")
        else:
            O(f"文本行数与清单一致（{len(body)}）")


# --------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="语音翻译/字幕 提交前体检")
    ap.add_argument("--hyp", help="翻译假设文件（一句一行）")
    ap.add_argument("--ref", help="参考译文文件")
    ap.add_argument("--lang-pair", default="en-zh", help="语言方向，如 en-zh")
    ap.add_argument("--srt", help="待检字幕 SRT")
    ap.add_argument("--srt-ref", help="参考字幕 SRT")
    ap.add_argument("--manifest", help="音频清单 TSV")
    ap.add_argument("--text", help="与清单对应的文本（一句一行）")
    a = ap.parse_args()

    print("=" * 72)
    print(" 语音翻译评测 · 提交前体检")
    print("=" * 72)

    if a.hyp and a.ref:
        check_text_pair(a.hyp, a.ref, a.lang_pair)
    if a.srt:
        check_srt(a.srt, a.srt_ref)
    if a.manifest:
        check_manifest(a.manifest, a.text)

    if not (a.hyp or a.srt or a.manifest):
        ap.error("至少提供 --hyp/--ref、--srt 或 --manifest 之一")

    print("\n" + "=" * 72)
    print(f" 结果：{len(ok)} OK / {len(warn)} WARN / {len(err)} ERROR")
    for m in err:
        print(f"   ✗ {m}")
    print("=" * 72)
    if err:
        print("\n结论：存在 ERROR，禁止提交。")
        sys.exit(1)
    print("\n结论：可以提交。")
    sys.exit(0)


if __name__ == "__main__":
    main()
