# 语音翻译评测工具包 st-evalkit

面向「基于跨模态统一语义表示的语音机器翻译研究」五项研究内容的**官方口径**评测工具集。
与任务1（TREC 检索评测）、任务2（CAD 自建评测集）同一套方法论：
**先划清官方与民间、先核实再动笔、用实证代替描述、工具受阻时给等价替代。**

> 数据目录下的 `data/demo/` 全部为**合成数据**，仅用于跑通流水线与证伪脚本，
> 不声称来自任何真实语料。评测方法与指标定义则全部对齐官方。

---

## 一、为什么语音翻译不能只报 BLEU

| 研究内容 | 官方评测依托 | 只看 BLEU 会漏掉什么 |
|---|---|---|
| 1 数据集建设 | IWSLT 数据条件（constrained/unconstrained） | 对齐噪声、时长分布、片段合法性 |
| 2 跨模态统一表示 | WMT 多模态任务、Multi30K、CoMMuTE | 语义表示好不好，BLEU 测不出来 |
| 3 语音翻译模型 | IWSLT Offline SLT | ASR 前端 vs MT 后端的归因 |
| 4 同声传译 | IWSLT Simultaneous ST | **延迟**——BLEU 鼓励"等说完再翻" |
| 5 多模态字幕系统 | IWSLT Subtitling（2022 起常设） | 分段、时间轴、每行字数等播出约束 |

**核心结论**：研究内容 4 必须有延迟指标，研究内容 5 必须有 SubER 与合规率，
否则评测与任务目标错位。

---

## 二、工具清单

| 脚本 | 作用 | 对应研究内容 |
|---|---|---|
| `make_demo_data.py` | 生成可复现的合成演示数据 | 全部 |
| `check_format.py` | 提交前体检，拦截静默故障 | 1 / 3 / 5 |
| `st_eval.py` | BLEU / chrF2 / TER / WER / CER | 3 |
| `subtitle_eval.py` | 官方 SubER + CPS/CPL/LPB 合规率 | 5 |
| `latency.py` | AL / DAL / AP / LAAL / StreamLAAL / SO | 4 |
| `significance.py` | 配对 bootstrap + 配对 t 检验 | 全部（结论可信度） |

依赖（本沙箱实测版本）：

```bash
pip install --break-system-packages sacrebleu jiwer subtitle-edit-rate jieba
# sacrebleu 2.5.1 / jiwer / subtitle-edit-rate 0.4.0 / jieba
# 注意：需 python3.12；SubER 官方 CLI 为 `suber`
```

---

## 三、实测结果（合成数据，`data/demo`）

### 3.1 离线翻译质量

| 系统 | BLEU ↑ | chrF2 ↑ | TER ↓ | ASR 端 WER ↓ |
|---|---|---|---|---|
| 端到端 e2e | **90.62** | **86.30** | **4.30** | 18.23 % |
| 级联 cascade | 75.91 | 69.06 | 12.07 | 18.23 % |

两者共用同一份 ASR 输出（WER 相同），差异**全部来自错误传播**——
这正是级联 vs 端到端的经典归因场景。
配对 bootstrap（B=10000，n=40）：差值 +16.94，95% CI [+10.96, +23.41]，p < 0.0001，显著。

### 3.2 字幕（研究内容 5）

| 字幕 | SubER ↓ | CPS 合规 | CPL 合规 | LPB 合规 |
|---|---|---|---|---|
| 压缩后（合规） | **6.98** | 100.00 % | 100.00 % | 100.00 % |
| 逐字转写（直出） | 155.81 | 0.00 % | 0.00 % | 100.00 % |

逐字版 BLEU 并不为 0（59.28），但 CPS 实测 16.00 字/秒（上限 9）、CPL 26 字/行（上限 16），
**完全不可播出**。这印证了 IWSLT 2026 字幕赛道的判读：
SubER 与合规率必须同时看，BLEU 单独看会给出错误结论。

### 3.3 同传延迟（研究内容 4）

| 策略 | AL ↓ | DAL ↓ | AP ↓ | LAAL ↓ | StreamLAAL ↓ | SO ↓ |
|---|---|---|---|---|---|---|
| wait-1 | **1.576** | **1.505** | **0.606** | **1.576** | **1.838** | **1.700** |
| wait-3 | 3.578 | 3.108 | 0.745 | 3.578 | 3.788 | 3.700 |
| wait-5 | 5.584 | 4.363 | 0.854 | 5.584 | 5.739 | 5.700 |
| wait-9 | 9.613 | 5.827 | 0.979 | 9.613 | 9.661 | 9.700 |
| offline | 11.625 | 6.095 | 1.000 | 11.625 | 11.625 | 11.625 |

单调性与理论一致：k 越大越准但越慢；offline 的 AP = 1.000 是理论上限。

---

## 四、四类静默故障（必须先体检）

语音翻译评测最致命的不是分数低，而是**分数看起来正常其实算错了**：

1. **假设/参考行数不一致** —— BLEU 按语料级 n-gram 统计，多一行少一行不报错，只悄悄稀释。
   实测：删掉 5 行后 `check_format.py` 立即报 ERROR；若直接算 BLEU 则无任何提示。
2. **恒定时间漂移** —— SubER 官方文档明确写道：
   *"Make sure that there is no constant time offset between the timestamps in
   hypothesis and reference as this will lead to incorrect scores."*
   本工具包在生成演示数据时曾出现 6 秒级累积漂移，导致 BLEU=100 却 SubER=65 的自相矛盾。
3. **SRT 毫秒溢出** —— `round(sec*1000)` 逐字段取整会产生 `,1000` 这种非法时间戳。
   已修：整体取整后再拆分。
4. **负时间戳** —— 时间抖动把首块推到 0 以下，产生 `-1:59:59,975`。已加钳位。

---

## 五、复现命令

```bash
cd /workspace/st-evalkit
python3.12 tools/make_demo_data.py

python3.12 tools/check_format.py --hyp data/demo/e2e.zh --ref data/demo/ref.zh --lang-pair en-zh
python3.12 tools/check_format.py --srt data/demo/hyp_raw.srt --srt-ref data/demo/ref.srt

python3.12 tools/st_eval.py --run e2e=data/demo/e2e.zh cascade=data/demo/cascade.zh \
    --ref data/demo/ref.zh --tgt-lang zh \
    --asr-hyp data/demo/asr.hyp.en --src data/demo/src.en --dump data/demo/scores.json

python3.12 tools/subtitle_eval.py --hyp data/demo/hyp_cond.srt --ref data/demo/ref.srt --lang zh
python3.12 tools/latency.py --waits data/demo/simul_waits.jsonl
python3.12 tools/significance.py --dump data/demo/scores.json --a e2e --b cascade --metric BLEU
```

---

## 六、与官方提交的关系（诚实声明）

* SubER 直接调用官方实现 `suber`（AppTek 开源），不做自造公式，分数可复现。
* BLEU/chrF2/TER 由 **SacreBLEU** 计算，输出 `signature` 版本指纹——
  论文必须一起报告，不同 tokenizer/版本不可直接比大小。
* 延迟指标中 **LAAL / StreamLAAL** 的网格取值在不同实现间有细微差异，
  本脚本用于离线复核与消融；**正式提交一律以官方 SimulEval 为准**，
  论文写 "computed with SimulEval"。
* COMET / BLEURT 等神经指标需自行安装 `unbabel-comet` 并下载百 MB 级模型，
  本工具包只给出接入位置，不内嵌权重。
